﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Soluções_Enfermagem
{
    public partial class Relatorio_CursoFeito : Form
    {
        int id;
        cmdRelatorio relatorio = new cmdRelatorio();
        Form currentChildForm;
        public Relatorio_CursoFeito(int cod)
        {
            InitializeComponent();
            id = cod;
        }
        private void openChildForm(Form childForm)
        {
            if (currentChildForm != null)
            {
                currentChildForm.Close();
            }
            currentChildForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panel_conteudo.Controls.Add(childForm);
            childForm.BringToFront();
            childForm.Show();
        }

        private void btn_voltar_Click_1(object sender, EventArgs e)
        {
            openChildForm(new Relatorio_Curso());
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Relatorio_CursoFeito_Load(object sender, EventArgs e)
        {
            MySqlDataReader temp = this.relatorio.relatorioCurso(id);
            DataTable dt = new DataTable();
            dt.Load(temp);
            table.DataSource = dt;
            this.relatorio.fech();
            temp = relatorio.numAlunosCurso(id);
            while (temp.Read())
            {
                txt_alunos.Text = temp.GetString(0);
            }
            this.relatorio.fech();
            temp = relatorio.numEndividaCurso(id);
            while (temp.Read())
            {
                txt_debito.Text = temp.GetString(0);
            }
            temp = relatorio.acharCurso(id);
            while (temp.Read())
            {
                if (temp.GetString(0).Length > 20)
                {
                    txt_alterar.Text = temp.GetString(0);
                    txt_alterar.Text = txt_alterar.Text.Substring(20);
                    txt_alterar.Text += "...";
                }
                else
                {
                    txt_alterar.Text = temp.GetString(0);
                }
                
            }
            this.relatorio.fech();
        }

        private void btn_pesquisar_Click_1(object sender, EventArgs e)
        {
            List<string> filtro = new List<string>();
            if (txt_codigo.Text != "")
            {
                filtro.Add("a.num_aluno = '" + txt_codigo.Text + "'");
            }
            if (txt_nome.Text != "")
            {
                filtro.Add("a.nome like '%" + txt_nome.Text + "%'");
            }
            if (txt_cep.MaskFull == true)
            {
                filtro.Add("cep = '" + txt_cep.Text + "'");
            }
            if (txt_celular.MaskFull == true)
            {
                filtro.Add("celular = '" + txt_celular.Text + "'");
            }
            if (txt_cpf.MaskFull == true)
            {
                filtro.Add("cpf = '" + txt_cpf.Text + "'");
            }
            if (cb_debito.Checked)
            {
                filtro.Add("a.num_aluno in (select a.num_aluno from aluno a, compra c where a.num_aluno = c.num_aluno and status = 'Não Pago')");
            }
            if (filtro.Count != 0)
            {
                string pesquisa = String.Join("and ", filtro.ToArray());
                try
                {
                    MySqlDataReader temp = this.relatorio.pequisarAlunosCurso(pesquisa);
                    DataTable dt = new DataTable();
                    dt.Load(temp);
                    table.DataSource = dt;
                    this.relatorio.fech();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void table_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (this.table.Columns[e.ColumnIndex].Name == "Status")
            {
                if (e.Value != null)
                {
                    if (e.Value is string)
                    {
                        string stringValue = (string)e.Value;
                        if (stringValue.StartsWith("Não") == true)
                        {
                            e.CellStyle.BackColor = Color.FromArgb(99, 161, 116);
                            //e.CellStyle.BackColor = Color.Green;
                            e.CellStyle.ForeColor = Color.White;
                        }
                        else
                        {
                            e.CellStyle.BackColor = Color.Tomato;
                            //e.CellStyle.BackColor = Color.Red;
                            e.CellStyle.ForeColor = Color.White;
                        }
                    }
                }
            }
        }

        private void btn_compra_atualizar_Click(object sender, EventArgs e)
        {
            MySqlDataReader temp = this.relatorio.relatorioCurso(id);
            DataTable dt = new DataTable();
            dt.Load(temp);
            table.DataSource = dt;
            this.relatorio.fech();
        }
    }
}
