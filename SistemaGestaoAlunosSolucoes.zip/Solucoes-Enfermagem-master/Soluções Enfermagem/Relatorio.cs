﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Soluções_Enfermagem
{
    public partial class Relatorio : Form
    {
        Form currentChildForm;
        Form currentChildForm2;
        public Relatorio()
        {
            InitializeComponent();
            openChildForm(new Relatorio_Curso());
            openChildForm2(new Relatorio_Total());
        }

        private void Relatorio_Load(object sender, EventArgs e)
        {

        }
        private void openChildForm(Form childForm)
        {
            if (currentChildForm != null)
            {
                currentChildForm.Close();
            }
            currentChildForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panel_conteudo.Controls.Add(childForm);
            childForm.BringToFront();
            childForm.Show();
        }
        private void openChildForm2(Form childForm)
        {
            if (currentChildForm2 != null)
            {
                currentChildForm2.Close();
            }
            currentChildForm2 = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panel_conteudo2.Controls.Add(childForm);
            childForm.BringToFront();
            childForm.Show();
        }

        private void panel_conteudo_Click(object sender, EventArgs e)
        {

        }
    }
}
