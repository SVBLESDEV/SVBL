﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Soluções_Enfermagem
{
    public partial class Editar_Funcionario : Form
    {
        private int id;
        cmdFuncionario func = new cmdFuncionario();
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd,
                         int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        public Editar_Funcionario(int num_func, string nome, string cargo, string coren)
        {
            InitializeComponent();
            id = num_func;
            txt_nome.Text = nome;
            txt_coren.Text = coren;
            txt_cargo.Text = cargo;
            func.inserirFuncionarioAchar(num_func, nome, cargo, coren);
            txt_telefone.Text = func.telefone;
            txt_celular.Text = func.celular;
            txt_email.Text = func.email;
            txt_cep.Text = func.cep;
            txt_estado.Text = func.estado;
            txt_municipio.Text = func.municipio;
            txt_bairro.Text = func.bairro;
            txt_rua.Text = func.rua;
            txt_numero.Text = func.numero.ToString();
            func.fech();
        }

        private void btn_fechar_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
        }

        private void Editar_Funcionario_Load(object sender, EventArgs e)
        {

        }

        private void btn_salvar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_nome.Text == "")
                {
                    lbl_erro.Text = "   Nome";
                    pnl_error.Visible = true;
                }
                else
                {
                    if (txt_cargo.Text == "")
                    {
                        lbl_erro.Text = "  Cargo";
                        pnl_error.Visible = true;
                    }
                    else
                    {
                        if (txt_coren.Text == "")
                        {
                            lbl_erro.Text = "coren";
                            pnl_error.Visible = true;
                        }
                        else
                        {
                            if (txt_cep.MaskFull == false)
                            {
                                lbl_erro.Text = "    CEP";
                                pnl_error.Visible = true;
                            }
                            else
                            {
                                if (txt_numero.Text == "")
                                {
                                    txt_numero.Text = "0";
                                    if (txt_telefone.MaskFull || txt_celular.MaskFull || txt_email.Text != "")
                                    {
                                        func.nome = txt_nome.Text;
                                        func.cargo = txt_cargo.Text;
                                        func.coren = txt_coren.Text;
                                        func.telefone = txt_telefone.Text;
                                        func.celular = txt_celular.Text;
                                        func.email = txt_email.Text;
                                        func.cep = txt_cep.Text;
                                        func.estado = txt_estado.Text;
                                        func.municipio = txt_municipio.Text;
                                        func.bairro = txt_bairro.Text;
                                        func.rua = txt_rua.Text;
                                        func.numero = int.Parse(txt_numero.Text);
                                        func.alterarFuncionario();
                                        MessageBox.Show("Editado com sucesso");
                                        Dispose();
                                    }
                                    else
                                    {
                                        lbl_erro.Text = "Contato";
                                        pnl_error.Visible = true;
                                    }
                                }
                                else
                                {
                                    if (txt_telefone.MaskFull || txt_celular.MaskFull || txt_email.Text != "")
                                    {
                                        func.nome = txt_nome.Text;
                                        func.cargo = txt_cargo.Text;
                                        func.coren = txt_coren.Text;
                                        func.telefone = txt_telefone.Text;
                                        func.celular = txt_celular.Text;
                                        func.email = txt_email.Text;
                                        func.cep = txt_cep.Text;
                                        func.estado = txt_estado.Text;
                                        func.municipio = txt_municipio.Text;
                                        func.bairro = txt_bairro.Text;
                                        func.rua = txt_rua.Text;
                                        func.numero = int.Parse(txt_numero.Text);
                                        func.alterarFuncionario();
                                        MessageBox.Show("Editado com sucesso");
                                        Dispose();
                                    }
                                    else
                                    {
                                        lbl_erro.Text = "Contato";
                                        pnl_error.Visible = true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            Dispose();
        }
    }
}
