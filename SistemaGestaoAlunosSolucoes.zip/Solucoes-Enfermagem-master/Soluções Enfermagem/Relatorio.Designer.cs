﻿namespace Soluções_Enfermagem
{
    partial class Relatorio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.panel_conteudo = new System.Windows.Forms.TabPage();
            this.panel_conteudo2 = new System.Windows.Forms.TabPage();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.panel_conteudo);
            this.tabControl1.Controls.Add(this.panel_conteudo2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1265, 755);
            this.tabControl1.TabIndex = 1;
            // 
            // panel_conteudo
            // 
            this.panel_conteudo.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel_conteudo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel_conteudo.Location = new System.Drawing.Point(4, 33);
            this.panel_conteudo.Name = "panel_conteudo";
            this.panel_conteudo.Padding = new System.Windows.Forms.Padding(3);
            this.panel_conteudo.Size = new System.Drawing.Size(1257, 718);
            this.panel_conteudo.TabIndex = 0;
            this.panel_conteudo.Text = "Curso";
            this.panel_conteudo.Click += new System.EventHandler(this.panel_conteudo_Click);
            // 
            // panel_conteudo2
            // 
            this.panel_conteudo2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel_conteudo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel_conteudo2.Location = new System.Drawing.Point(4, 33);
            this.panel_conteudo2.Name = "panel_conteudo2";
            this.panel_conteudo2.Padding = new System.Windows.Forms.Padding(3);
            this.panel_conteudo2.Size = new System.Drawing.Size(1357, 818);
            this.panel_conteudo2.TabIndex = 1;
            this.panel_conteudo2.Text = "Total";
            // 
            // Relatorio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1265, 755);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Relatorio";
            this.Text = "Relatorio";
            this.Load += new System.EventHandler(this.Relatorio_Load);
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage panel_conteudo;
        private System.Windows.Forms.TabPage panel_conteudo2;
    }
}