﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Soluções_Enfermagem
{
    internal class cmdCompra
    {
        int num_aluno { get; set; }
        int num_curso { get; set; }
        public string nome_aluno { get; set; }
        public string nome_curso { get; set; }
        public double valor { get; set; }
        public string bonus { get; set; }
        Banco banco = new Banco();
        public cmdCompra()
        {

        }
        public cmdCompra(string c, string a)
        {
            num_aluno = int.Parse(a);
            num_curso = int.Parse(c);
            MySqlDataReader reader;
            this.banco.conectar();
            reader = this.banco.Query("select nome,bonus from aluno where num_aluno = '"+ num_aluno + "';");
            reader.Read();
            nome_aluno = reader.GetString(0);
            bonus = reader.GetString(1);
            this.banco.close();
            this.banco.conectar();
            reader = this.banco.Query("select nome,valor from curso where num_curso = '"+ num_curso + "';");
            reader.Read();
            nome_curso = reader.GetString(0);
            valor = reader.GetDouble(1);
            this.banco.close();
        }
        public void efetuarCompra(string final, string tipo, DateTime data, string status, int quantidade, bool bonus)
        {
            double bonus_valor;
            if (bonus == true)
            {
                bonus_valor = (this.valor * 0.1) / quantidade;
            }
            else
            {
                bonus_valor = 0;
            }
            this.banco.conectar();
            this.banco.Query("insert into compra (pagamento_efetuado,tipo_pagamento,data_pagamento,valor_compra,valor_bonus,status,num_aluno,num_curso)  values ('" + final + "', '" + tipo + "', '" + data.Year.ToString() + "-" + data.Month.ToString() + "-" + data.Day.ToString() + "', '" + (this.valor.ToString()).Replace(',','.') + "', '" + (bonus_valor.ToString()).Replace(',','.') + "', '"+status+ "', '" + this.num_aluno + "', '" + this.num_curso + "');");
            this.banco.close();
        }
        public MySqlDataReader listarCompras()
        {
            this.banco.conectar();
            return this.banco.Query("select num_compra 'Codigo', a.nome 'Nome', cu.nome 'Curso', valor_compra 'Valor Do Curso', tipo_pagamento 'Tipo', data_pagamento 'Data',pagamento_efetuado 'Total' , valor_bonus 'Bonus', status 'Status' from compra c, aluno a, curso cu where c.num_aluno = a.num_aluno and c.num_curso = cu.num_curso order by num_compra desc; ");
        }
        public MySqlDataReader pesquisarCompras(string filtro)
        {
            this.banco.conectar();
            return this.banco.Query("select num_compra 'Codigo', a.nome 'Nome', cu.nome 'Curso', tipo_pagamento 'Tipo', data_pagamento 'Data', valor_compra 'Valor Do Curso', valor_bonus 'Bonus', pagamento_efetuado 'Total', status 'Status' from compra c, aluno a, curso cu where c.num_aluno = a.num_aluno and c.num_curso = cu.num_curso and " + filtro+"; ");
        }
        public void mudarBonus()
        {
            this.banco.conectar();
            this.banco.Query("update aluno set bonus = 'Sim' where num_aluno='"+num_aluno+"';");
            this.banco.close();
        }
        public void excluirCompra(int cod)
        {
            this.banco.conectar();
            this.banco.Query("delete from compra where num_compra = '"+cod+"';");
            this.banco.close();
        }
        public void fech()
        {
            this.banco.close();
        }
        public void alterarCompra(string final, string tipo, DateTime data, string status, int quantidade, bool bonus, int cod)
        {
            double bonus_valor;
            if (bonus == true)
            {
                bonus_valor = this.valor * 0.1;
            }
            else
            {
                bonus_valor = 0;
            }
            this.banco.conectar();
            this.banco.Query("update compra set pagamento_efetuado= '"+final+ "', tipo_pagamento='"+tipo+ "', data_pagamento='" + data.Year.ToString() + "-" + data.Month.ToString() + "-" + data.Day.ToString() + "', valor_bonus= '"+bonus_valor+ "', status= '"+status+"' where num_compra = '"+cod+"';");
            this.banco.close();
        }
        public void criarInscrição()
        {
            DateTime agr = DateTime.Now;
            this.banco.conectar();
            this.banco.Query("insert into inscricao (data_inscricao, num_aluno, num_curso) values ('" + agr.Year.ToString() + "-" + agr.Month.ToString() + "-" + agr.Day.ToString() + " "+agr.TimeOfDay.ToString()+"','" +this.num_aluno+"','"+this.num_curso+"');");
            this.banco.close();
        }
        public int getInscrição(string num, string id)
        {
            this.banco.conectar();
            MySqlDataReader reader = this.banco.Query("select data_inscricao from inscricao where num_curso='" + num + "' and num_aluno='" + id + "'; ");
            if (reader.Read())
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }
        public int cursoCompras(int cod)
        {
            string id="", num="";
            int i = 1;
            this.banco.conectar();
            MySqlDataReader reader = this.banco.Query("select c.num_curso, c.num_aluno from compra c, aluno a, curso cu where num_compra = "+cod+" and c.num_aluno = a.num_aluno and c.num_curso = cu.num_curso order by num_compra desc; ");
            while (reader.Read())
            {
                num = reader.GetString(0);
                id = reader.GetString(1);
            }
            this.banco.close();
            this.banco.conectar();
            reader = this.banco.Query("select count(num_compra) from compra c, aluno a, curso cu where c.num_curso = " + num + " and c.num_aluno = "+id+" and c.num_aluno = a.num_aluno and c.num_curso = cu.num_curso order by num_compra desc; ");
            while (reader.Read())
            {
                i = reader.GetInt32(0);
            }
            if (i == 1)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        public void excluirInscrição(int cod)
        {
            string num = "", id = "";
            this.banco.conectar();
            MySqlDataReader reader = this.banco.Query("select c.num_curso, c.num_aluno from compra c, aluno a, curso cu where num_compra = " + cod + " and c.num_aluno = a.num_aluno and c.num_curso = cu.num_curso order by num_compra desc; ");
            while (reader.Read())
            {
                num = reader.GetString(0);
                id = reader.GetString(1);
            }
            this.banco.close();
            this.banco.conectar();
            this.banco.Query("delete from inscricao where num_aluno="+id+" and num_curso="+num+";");
            this.banco.close();
        }
    }
}
