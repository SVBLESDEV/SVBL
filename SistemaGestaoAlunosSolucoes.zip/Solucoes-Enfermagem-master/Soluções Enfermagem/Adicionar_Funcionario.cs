﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Soluções_Enfermagem
{
    public partial class Adicionar_Funcionario : Form
    {
        cmdFuncionario func = new cmdFuncionario();
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd,
                         int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        public Adicionar_Funcionario()
        {
            InitializeComponent();
        }

        private void btn_fechar_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
        }

        private void btn_salvar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_nome.Text == "")
                {
                    lbl_erro.Text = "    Nome";
                    pnl_error.Visible = true;
                }
                else
                {
                    if (txt_cargo.Text == "")
                    {
                        lbl_erro.Text = "    Cargo";
                        pnl_error.Visible = true;
                    }
                    else
                    {
                        if (txt_coren.Text == "")
                        {
                            lbl_erro.Text = "   coren";
                            pnl_error.Visible = true;
                        }
                        else
                        {
                            if (txt_cep.MaskFull == false)
                            {
                                lbl_erro.Text = "     CEP";
                                pnl_error.Visible = true;
                            }
                            else
                            {
                                if (txt_numero.Text == "")
                                {
                                    txt_numero.Text = "0";
                                    if (txt_telefone.MaskFull || txt_celular.MaskFull || txt_email.Text != "")
                                    {
                                        func.inserirFuncionario(txt_nome.Text, txt_cargo.Text, txt_coren.Text, txt_celular.Text, txt_telefone.Text, txt_email.Text, txt_cep.Text, txt_rua.Text, int.Parse(txt_numero.Text), txt_bairro.Text, txt_estado.Text, txt_municipio.Text);
                                        MessageBox.Show("Adicionado com sucesso");
                                        Dispose();
                                    }
                                    else
                                    {
                                        lbl_erro.Text = "Contato";
                                        pnl_error.Visible = true;
                                    }
                                }
                                else
                                {
                                    if (txt_telefone.MaskFull || txt_celular.MaskFull || txt_email.Text != "")
                                    {
                                        func.inserirFuncionario(txt_nome.Text, txt_cargo.Text, txt_coren.Text, txt_celular.Text, txt_telefone.Text, txt_email.Text, txt_cep.Text, txt_rua.Text, int.Parse(txt_numero.Text), txt_bairro.Text, txt_estado.Text, txt_municipio.Text);
                                        MessageBox.Show("Adicionado com sucesso");
                                        Dispose();
                                    }
                                    else
                                    {
                                        lbl_erro.Text = "Contato";
                                        pnl_error.Visible = true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txt_estado_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
