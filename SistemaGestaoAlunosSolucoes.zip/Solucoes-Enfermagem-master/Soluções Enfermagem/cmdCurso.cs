﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using MySql.Data.MySqlClient;

namespace Soluções_Enfermagem
{
    internal class cmdCurso
    {
        public int id { get; set; }
        public string nome { get; set; }
        public string valor { get; set; }
        public int carga_horaria { get; set; }
        public DateTime inicio { get; set; }
        public DateTime fim { get; set; }
        public Banco banco = new Banco();
        public cmdCurso()
        {

        }
        public void fech()
        {
            this.banco.close();
        }
        public MySqlDataReader listarCursos()
        {
            this.banco.conectar();
            return this.banco.Query("select num_curso 'Codigo', nome 'Nome', valor 'Valor', carga_horaria 'Carga Horaria', periodo_inicio 'Inicio', periodo_fim 'Fim' from curso;");
        }
        public MySqlDataReader pesquisarCurso(string filtro)
        {
            this.banco.conectar();
            return this.banco.Query("select num_curso 'Codigo', nome 'Nome', valor 'Valor', carga_horaria 'Carga Horaria', periodo_inicio 'Inicio', periodo_fim 'Fim' from curso where " + filtro + ";");
        }
        private void cadastrarCurso()
        {
            this.banco.conectar();
            this.banco.nonQuery("insert into curso (nome,valor,carga_horaria,periodo_inicio,periodo_fim)  values ('" + this.nome + "', '" + this.valor + "', '" + this.carga_horaria + "', '" + this.inicio.Year.ToString() +"-" + this.inicio.Month.ToString() + "-" + this.inicio.Day.ToString() + "', '" + this.fim.Year.ToString() + "-" + this.fim.Month.ToString() + "-" + this.fim.Day.ToString() + "')");
            this.banco.close();
        }
        public void inserirCurso(string nome, int carga, string valor, string inicio_ano, string inicio_mes, string inicio_dia, string fim_ano, string fim_mes, string fim_dia)
        {
            DateTime inicio = DateTime.Parse(inicio_ano + "-" + inicio_mes + "-" + inicio_dia);
            DateTime fim = DateTime.Parse(fim_ano + "-" + fim_mes + "-" + fim_dia);
            this.nome = nome;
            this.carga_horaria = carga;
            this.valor = valor;
            this.inicio = inicio;
            this.fim = fim;
            cadastrarCurso();
        }
        public void alterarCurso()
        {
            this.banco.conectar();
            this.banco.nonQuery("update curso set nome = '" + this.nome + "', valor = '" + this.valor + "', carga_horaria = '" + this.carga_horaria + "', periodo_inicio = '" + this.inicio.Year.ToString() + "-" + this.inicio.Month.ToString() + "-" + this.inicio.Day.ToString() + "', periodo_fim = '" + this.fim.Year.ToString() + "-" + this.fim.Month.ToString() + "-" + this.fim.Day.ToString() + "' where num_curso = '" + this.id + "';");
            this.banco.close();
        }
        public int excluirCurso(int id)
        {
            this.banco.conectar();
            MySqlDataReader reader = this.banco.Query("select * from curso c, compra p where p.num_curso=c.num_curso;");
            this.banco.close();
            if (reader.HasRows)
            {
                return -1;
            }
            else
            {
                this.banco.conectar();
                this.banco.nonQuery("delete from curso where num_curso = '" + id + "'");
                this.banco.close();
                return 0;
            }            
        }
    }
}
