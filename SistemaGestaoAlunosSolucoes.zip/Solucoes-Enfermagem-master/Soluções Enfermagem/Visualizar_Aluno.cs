﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Drawing.Drawing2D;
using MySql.Data.MySqlClient;

namespace Soluções_Enfermagem
{
    public partial class Visualizar_Aluno : Form
    {
        private int id;
        private string nome;
        private string num_curso;
        private string tipo;
        private string p1 = "";
        private string p2 = "";
        private string p3 = "";
        private string p4 = "";
        private string a = " ", b = " ", c = " ", d = " ", ed = " ", f = " ", g = " ", h = " ", i = " ", j = " ", k = " ", outros = " ", tipo1 = " ", tipo2 = " ", tipo3 = " ", tipo4 = " ";
        private (string, string) datas;
        cmdAluno aluno = new cmdAluno();

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd,
                         int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        public Visualizar_Aluno(int num_aluno, string nome, int idade, string sexo, string rg, string cpf)
        {
            InitializeComponent();
            id = num_aluno;
            txt_nome.Text = nome;
            txt_idade.Text = idade.ToString();
            txt_cpf.Text = cpf;
            txt_rg.Text = rg;
            txt_sexo.Text = sexo;
            aluno.inserirAlunoAchar(num_aluno, nome, idade, sexo, rg, cpf);
            txt_telefone.Text = aluno.telefone;
            txt_celular.Text = aluno.celular;
            txt_email.Text = aluno.email;
            txt_cep.Text = aluno.cep;
            txt_estado.Text = aluno.estado;
            txt_municipio.Text = aluno.municipio;
            txt_bairro.Text = aluno.bairro;
            txt_rua.Text = aluno.rua;
            txt_numero.Text = aluno.numero.ToString();
            aluno.fech();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void btn_fechar_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
        }

        private void panel2_Paint(object sender, PaintEventArgs e){}

        private void Visualizar_Aluno_Load(object sender, EventArgs e)
        {
            MySqlDataReader temp = this.aluno.cursosAluno(id);
            DataTable dt = new DataTable();
            dt.Load(temp);
            table.DataSource = dt;
            this.aluno.fech();
        }

        private void btn_imprimir_Click(object sender, EventArgs e)
        {
            if ((txt_alterar.Text == "{txt}") || (txt_alterar.Text == "Selecione um curso"))
            {
                txt_alterar.Text = "Selecione um curso";
                txt_alterar.Visible = true;
            }
            else
            {
                printDialog1.Document = printDocument1;

                if (printDialog1.ShowDialog() == DialogResult.OK)
                {
                    this.printDocument1.Print();
                }
            }            
        }
        private List<string> getEndereco()
        {
            List<string> endereco = new List<string>();
            int cont=0, linha=70;
            if (txt_cep.MaskFull == true)
            {
                endereco.Add("CEP: "+txt_cep.Text);
            }
            if (txt_estado.Text != "")
            {
                endereco.Add("Estado: " + txt_estado.Text);
            }
            if (txt_rua.Text != "")
            {
                endereco.Add("Rua: " + txt_rua.Text);
            }
            if (txt_municipio.Text != "")
            {
                endereco.Add("Municipio: " + txt_municipio.Text);
            }
            if (txt_bairro.Text != "")
            {
                endereco.Add("Bairro: " + txt_bairro.Text);
            }
            if (txt_numero.Text != "0")
            {
                endereco.Add("Numero: " + txt_numero.Text);
            }
            for(int i = 0; i < endereco.Count; i++)
            {
                cont += endereco[i].Length;
                if(cont >= linha)
                {
                    endereco[i] += "\n";
                    linha = linha + 70;
                }
            }
            return endereco;
        }

        private List<string> getTelefone()
        {
            List<string> telefone = new List<string>();
            if (txt_celular.MaskFull == true)
            {
                telefone.Add(txt_celular.Text);
            }
            if (txt_telefone.MaskFull == true)
            {
                telefone.Add(txt_telefone.Text);
            }
            return telefone;
        }        
        private static System.Drawing.Image resizeImage(System.Drawing.Image imgToResize, Size size)
        {
            //Get the image current width  
            int sourceWidth = imgToResize.Width;
            //Get the image current height  
            int sourceHeight = imgToResize.Height;
            float nPercent = 0;
            float nPercentW = 0;
            float nPercentH = 0;
            //Calulate  width with new desired size  
            nPercentW = ((float)size.Width / (float)sourceWidth);
            //Calculate height with new desired size  
            nPercentH = ((float)size.Height / (float)sourceHeight);
            if (nPercentH < nPercentW)
                nPercent = nPercentH;
            else
                nPercent = nPercentW;
            //New Width  
            int destWidth = (int)(sourceWidth * nPercent);
            //New Height  
            int destHeight = (int)(sourceHeight * nPercent);
            Bitmap b = new Bitmap(destWidth, destHeight);
            Graphics g = Graphics.FromImage((System.Drawing.Image)b);
            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            // Draw image with new width and height  
            g.DrawImage(imgToResize, 0, 0, destWidth, destHeight);
            g.Dispose();
            return (System.Drawing.Image)b;
        }



        private void printDocument1_PrintPage_1(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            System.Drawing.Image ima = resizeImage(pictureBox1.Image, new Size(300, 150));

            e.Graphics.DrawImage(ima, new PointF(40, 20));
            //e.Graphics.DrawString(richTextBox1.Text, new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new PointF(130, 130));

            List<string> end = getEndereco();
            List<string> tel = getTelefone();
            string inscr = this.aluno.dataInscrição(num_curso,id);
            this.aluno.fech();
            acharCurso();
            acharCompras();
            acharTipo();
            e.Graphics.DrawString("FICHA DE CADASTRO DE ALUNOS ", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new PointF(260, 120));
            Pen blackPen = new Pen(Color.Black, 1);
            e.Graphics.DrawRectangle(blackPen, 96, 175, 650, 50);
            e.Graphics.DrawString("Nome completo: "+txt_nome.Text, new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new PointF(100, 180));
            e.Graphics.DrawRectangle(blackPen, 96, 225, 650, 66);
            e.Graphics.DrawString("Endereço: ", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new PointF(100, 228));
            e.Graphics.DrawString(String.Join("  ", end.ToArray()), new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new PointF(100, 249));
            e.Graphics.DrawRectangle(blackPen, 96, 291, 650, 24);
            e.Graphics.DrawString("Data de nascimento: ", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new PointF(100, 292));
            e.Graphics.DrawRectangle(blackPen, 96, 315, 650, 24);
            e.Graphics.DrawString("Telefones:  "+ String.Join("  ", tel.ToArray()), new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new PointF(100, 316));
            e.Graphics.DrawRectangle(blackPen, 96, 339, 650, 40);
            e.Graphics.DrawString("Email: "+txt_email.Text, new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new PointF(100, 340));
            e.Graphics.DrawRectangle(blackPen, 96, 379, 650, 24);
            e.Graphics.DrawString("Documentação: RG: "+txt_rg.Text, new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new PointF(100, 379));
            e.Graphics.DrawString("CPF: " + txt_cpf.Text, new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new PointF(500, 379));
            e.Graphics.DrawRectangle(blackPen, 96, 403, 650, 24);
            e.Graphics.DrawString("Turno: Manhã(  ) Tarde(  ) Noite(  ) Sábado(  ) Domingo(  )", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new PointF(100, 403));
            e.Graphics.DrawRectangle(blackPen, 96, 427, 650, 24);
            e.Graphics.DrawString("Formas de pagamento: ", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new PointF(100, 427));
            e.Graphics.DrawRectangle(blackPen, 96, 451, 650, 24);
            e.Graphics.DrawString("(  "+tipo1+"  ) cartão de crédito/débito", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new PointF(100, 451));
            e.Graphics.DrawRectangle(blackPen, 96, 475, 650, 24);
            e.Graphics.DrawString("(  " + tipo2 + "  ) boleto bancário", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new PointF(100, 475));
            e.Graphics.DrawRectangle(blackPen, 96, 499, 650, 24);
            e.Graphics.DrawString("(  " + tipo3 + "  ) dinheiro", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new PointF(100, 499));
            e.Graphics.DrawRectangle(blackPen, 96, 523, 650, 24);
            e.Graphics.DrawString("(  " + tipo4 + "  ) Picpay", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new PointF(100, 523));
            e.Graphics.DrawRectangle(blackPen, 96, 547, 650, 24);
            e.Graphics.DrawString("Valores:", new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new PointF(100, 547));
            e.Graphics.DrawRectangle(blackPen, 96, 571, 650, 35);
            e.Graphics.DrawString("1ª parcela: "+p1, new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new PointF(100, 571));
            e.Graphics.DrawRectangle(blackPen, 96, 606, 650, 35);
            e.Graphics.DrawString("2ª parcela: "+p2, new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new PointF(100, 606));
            e.Graphics.DrawRectangle(blackPen, 96, 641, 650, 35);
            e.Graphics.DrawString("3ª parcela: "+p3, new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new PointF(100, 641));
            e.Graphics.DrawRectangle(blackPen, 96, 676, 650, 35);
            e.Graphics.DrawString("4ª parcela: "+p4, new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new PointF(100, 676));
            e.Graphics.DrawRectangle(blackPen, 96, 711, 650, 140);
            e.Graphics.DrawString("Curso: Nefrologia e TRS (  "+a+"  ) UTI/UTIN (  "+b+ "  ) Injetáveis (  " + c + "  ) Cálculo de" +
                "\n medicações (  " + d + "  ) Lesões e curativos (  " + ed + "  ) Instrumentação cirúrgica (  " + f + "  ) " +
                "\nOncologia e cuidados paliativos (  " + g + "  ) Primeiros socorros (  " + h + "  ) Socorrista (  " + i + "  ) " +
                "\nManuseio em bomba infusora (  " + j + "  ) Vacinação e imunização (  " + k + "  ) outros : "+outros, new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new PointF(100, 711));
            e.Graphics.DrawRectangle(blackPen, 96, 851, 650, 60);
            e.Graphics.DrawString("Início de curso: "+datas.Item1.Substring(0, 10) +
                "\nTérmino de curso: "+datas.Item2.Substring(0, 10) +
                "\nData de inscrição: "+inscr, new Font("Arial", 12, FontStyle.Regular), Brushes.Black, new PointF(100, 851));
        }
        private void acharTipo()
        {
            if (tipo == "Credito" || tipo == "Debito")
            {
                tipo1 = "X";
            }
            if (tipo == "Boleto")
            {
                tipo2 = "X";
            }
            if (tipo == "Dinheiro")
            {
                tipo3 = "X";
            }
            if (tipo == "PicPay" || tipo == "Pix")
            {
                tipo4 = "X";
            }
        }
        private void acharCompras()
        {
            List<(string,string,string,string)> list = this.aluno.acharParcelas(num_curso, txt_nome.Text);
            this.aluno.fech();
            tipo = list[0].Item3;
            if(list[0].Item4 == "Não Pago")
            {
                p1 = list[0].Item1 +"   "+ list[0].Item2.Substring(0, 10);
            }
            else
            {
                p1 = list[0].Item1 + "   " + list[0].Item2.Substring(0,10) + "   " + list[0].Item4;
            }
            if (list.Count>1)
            {
                if (list[1].Item4 == "Não Pago")
                {
                    p2 = list[1].Item1 + "   " + list[1].Item2.Substring(0, 10);
                }
                else
                {
                    p2 = list[1].Item1 + "   " + list[1].Item2.Substring(0, 10) + "   " + list[1].Item4;
                }
                if (list.Count > 2)
                {
                    if (list[2].Item4 == "Não Pago")
                    {
                        p3 = list[2].Item1 + "   " + list[2].Item2.Substring(0, 10);
                    }
                    else
                    {
                        p3 = list[2].Item1 + "   " + list[2].Item2.Substring(0, 10) + "   " + list[2].Item4;
                    }
                    if (list.Count > 3)
                    {
                        if (list[3].Item4 == "Não Pago")
                        {
                            p4 = list[3].Item1 + "   " + list[3].Item2.Substring(0, 10);
                        }
                        else
                        {
                            p4 = list[3].Item1 + "   " + list[3].Item2.Substring(0, 10) + "   " + list[3].Item4;
                        }
                    }
                }
            }
        }
        private void acharCurso()
        {
            datas = this.aluno.dataCursos(num_curso);
            this.aluno.fech();
            if (nome == "Nefrologia e TRS")
            {
                a = "X";
            }
            else
            {
                if (nome == "UTI/UTIN")
                {
                    b = "X";
                }
                else
                {
                    if (nome == "Injetáveis")
                    {
                        c = "X";
                    }
                    else
                    {
                        if (nome == "Cálculo de medicações")
                        {
                            d = "X";
                        }
                        else
                        {
                            if (nome == "Lesões e curativos")
                            {
                                ed = "X";
                            }
                            else
                            {
                                if (nome == "Instrumentação cirúrgica")
                                {
                                    f = "X";
                                }
                                else
                                {
                                    if (nome == "Oncologia e cuidados paliativos")
                                    {
                                        g = "X";
                                    }
                                    else
                                    {
                                        if (nome == "Primeiros socorros")
                                        {
                                            h = "X";
                                        }
                                        else
                                        {
                                            if (nome == "Socorrista")
                                            {
                                                i = "X";
                                            }
                                            else
                                            {
                                                if (nome == "Manuseio em bomba infusora")
                                                {
                                                    j = "X";
                                                }
                                                else
                                                {
                                                    if (nome == "Vacinação e imunização")
                                                    {
                                                        k = "X";
                                                    }
                                                    else
                                                    {
                                                        outros = "\n"+nome + " (  X  ) ";
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        private void table_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow linha = table.Rows[e.RowIndex];
            txt_alterar.Text = linha.Cells[1].Value.ToString();
            nome = linha.Cells[1].Value.ToString();
            num_curso = linha.Cells[0].Value.ToString();
            txt_alterar.Visible = true;
        }
    }
}
