﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Soluções_Enfermagem
{
    public partial class Editar_Curso : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd,
                         int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        public int id;
        cmdCurso curso = new cmdCurso();
        public Editar_Curso(int num, string nome, string valor, int carga, string inicio, string fim)
        {
            InitializeComponent();
            id = num;
            txt_nome.Text = nome;
            txt_cargahoraria.Text = carga.ToString();
            txt_valor.Text = valor;
            dt_inicio.Value = DateTime.Parse(inicio);
            dt_fim.Value = DateTime.Parse(fim);
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void btn_fechar_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
        }

        private void btn_salvar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_nome.Text == "")
                {
                    lbl_erro.Text = "      Nome";
                    pnl_error.Visible = true;
                }
                else
                {
                    if (txt_cargahoraria.Text == "")
                    {
                        lbl_erro.Text = "Carga Horaria";
                        pnl_error.Visible = true;
                    }
                    else
                    {
                        if (txt_valor.Text == "")
                        {
                            lbl_erro.Text = "       Valor";
                            pnl_error.Visible = true;
                        }
                        else
                        {
                            this.curso.id = id;
                            this.curso.nome = txt_nome.Text;
                            this.curso.valor = txt_valor.Text;
                            this.curso.carga_horaria = int.Parse(txt_cargahoraria.Text);
                            this.curso.inicio = dt_inicio.Value;
                            this.curso.fim = dt_fim.Value;
                            this.curso.alterarCurso();
                            MessageBox.Show("Editado com sucesso");
                            Dispose();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
