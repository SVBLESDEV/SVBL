﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Soluções_Enfermagem
{
    public partial class Funcionario : Form
    {
        cmdFuncionario func = new cmdFuncionario();
        private int num_func { get; set; }
        private string nome { get; set; }
        private string cargo { get; set; }
        private string cpf { get; set; }
        public Funcionario()
        {
            InitializeComponent();
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e){}

        private void btn_adicionar_Click(object sender, EventArgs e)
        {
            Adicionar_Funcionario func = new Adicionar_Funcionario();
            func.ShowDialog();
        }

        private void btn_excluir_Click(object sender, EventArgs e)
        {
            if ((txt_alterar.Text == "{txt}") || (txt_alterar.Text == "Selecione um funcionario"))
            {
                txt_alterar.Text = "Selecione um contato";
                txt_alterar.Visible = true;
            }
            else
            {
                Excluir_Funcionario func = new Excluir_Funcionario(num_func, nome, cargo, cpf);
                func.ShowDialog();
                MySqlDataReader temp = this.func.listarFuncionarios();
                DataTable dt = new DataTable();
                dt.Load(temp);
                table.DataSource = dt;
                this.func.fech();
            }
            
        }

        private void Funcionario_Load(object sender, EventArgs e)
        {
            MySqlDataReader temp = this.func.listarFuncionarios();
            DataTable dt = new DataTable();
            dt.Load(temp);
            table.DataSource = dt;
            this.func.fech();
        }

        private void table_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataGridViewRow linha = table.Rows[e.RowIndex];
                txt_alterar.Text = linha.Cells[0].Value.ToString();
                num_func = int.Parse(linha.Cells[0].Value.ToString());
                nome = linha.Cells[1].Value.ToString();
                cargo = linha.Cells[2].Value.ToString();
                cpf = linha.Cells[3].Value.ToString();
                txt_alterar.Visible = true;
            }
            catch (Exception ex)
            {

            }
        }

        private void btn_editar_Click_1(object sender, EventArgs e)
        {
            if ((txt_alterar.Text == "{txt}") || (txt_alterar.Text == "Selecione um funcionario"))
            {
                txt_alterar.Text = "Selecione um funcionario";
                txt_alterar.Visible = true;
            }
            else
            {
                new Editar_Funcionario(num_func, nome, cargo, cpf).ShowDialog();
            }
        }

        private void btn_atualizar_Click(object sender, EventArgs e)
        {
            MySqlDataReader temp = this.func.listarFuncionarios();
            DataTable dt = new DataTable();
            dt.Load(temp);
            table.DataSource = dt;
            this.func.fech();
        }

        private void btn_visualizar_Click(object sender, EventArgs e)
        {
            if ((txt_alterar.Text == "{txt}") || (txt_alterar.Text == "Selecione um funcionario"))
            {
                txt_alterar.Text = "Selecione um funcionario";
                txt_alterar.Visible = true;
            }
            else
            {
                new Visualizar_Funcionario(num_func, nome, cargo, cpf).ShowDialog();
            }
        }

        private void btn_pesquisar_Click(object sender, EventArgs e)
        {
            List<string> filtro = new List<string>();
            if (txt_codigo.Text != "")
            {
                filtro.Add("num_func = '" + txt_codigo.Text + "'");
            }
            if (txt_nome.Text != "")
            {
                filtro.Add("nome like '%" + txt_nome.Text + "%'");
            }
            if (txt_cep.MaskFull == true)
            {
                filtro.Add("cep = '" + txt_cep.Text + "'");
            }
            if (txt_celular.MaskFull == true)
            {
                filtro.Add("celular = '" + txt_celular.Text + "'");
            }
            if (txt_coren.Text != "")
            {
                filtro.Add("coren = '" + txt_coren.Text + "'");
            }
            if (txt_cargo.Text != "")
            {
                filtro.Add("sexo = '" + txt_cargo.Text + "'");
            }
            if (filtro.Count != 0)
            {
                string pesquisa = String.Join("and ", filtro.ToArray());
                try
                {
                    MySqlDataReader temp = this.func.pequisarFuncionario(pesquisa);
                    DataTable dt = new DataTable();
                    dt.Load(temp);
                    table.DataSource = dt;
                    this.func.fech();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
