﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Soluções_Enfermagem
{
    internal class cmdLogin
    {
        public string logins { get; set; }
        public string senhas { get; set; }

        public Banco banco = new Banco();

        public cmdLogin()
        {

        }

        public void fech()
        {
            this.banco.close();
        }


        public string Loginbd()
        {
            this.banco.conectar();
            // this.banco.nonQuery("SELECT * FROM Users WHERE UseName='" + login + "' AND Password='" + senha + "'");
            try
            {
                MySqlDataReader reader = this.banco.Query("SELECT * FROM login WHERE usuario='" + this.logins + "' AND senha='" + this.senhas + "'");

                if (reader.Read())
                {
                    return "aceito";

                }
                else
                {
                    return "negado";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            fech();
            return "negado";
        }
    }
}
