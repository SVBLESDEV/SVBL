﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Soluções_Enfermagem
{
    public partial class Excluir_Funcionario : Form
    {
        private int id;
        cmdFuncionario func = new cmdFuncionario();
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd,
                         int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        public Excluir_Funcionario(int num_func, string nome, string cargo, string cpf)
        {
            InitializeComponent();
            id = num_func;
            txt_nome.Text = nome;
            txt_cpf.Text = cpf;
            txt_cargo.Text = cargo;
            func.inserirFuncionarioAchar(num_func, nome, cargo, cpf);
            txt_telefone.Text = func.telefone;
            txt_celular.Text = func.celular;
            txt_email.Text = func.email;
            txt_cep.Text = func.cep;
            txt_estado.Text = func.estado;
            txt_municipio.Text = func.municipio;
            txt_bairro.Text = func.bairro;
            txt_rua.Text = func.rua;
            txt_numero.Text = func.numero.ToString();
            func.fech();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            try
            {
                func.excluirFuncionario(id);
                MessageBox.Show("Aluno Excluido");
                Dispose();
            }
            catch (Exception ex)
            {

            }
        }

        private void panel1_MouseDown_1(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
        }

        private void btn_fechar_Click_1(object sender, EventArgs e)
        {
            Dispose();
        }
    }
}
