﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Soluções_Enfermagem
{
    public partial class Editar_Compra : Form
    {
        private int id;
        bool bonus;
        bool bonus_original;
        double original;
        cmdCompra compra = new cmdCompra();
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd,
                         int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        public Editar_Compra(int cod, string aluno, string curso, string total, string tipo, string data, string valor, string bonus, string status)
        {
            InitializeComponent();
            txt_aluno.Text = aluno;
            txt_curso.Text = curso;
            cmb_tipo.Text = tipo;
            txt_data.Text = data;
            txt_valor.Text = valor;
            if(status == "Pago")
            {
                rdbtn_pago.Checked = true;
            }
            else
            {
                rdbtn_naopago.Checked = true;
            }
            if (bonus == "0,00")
            {
                cmb_bonus.Text = "Não";
                bonus_original = false;
            }
            else
            {
                cmb_bonus.Text = "Sim";
                bonus_original=true;
            }
            original = double.Parse(total);
            txt_final.Text = total;
            id = cod;
        }

        private void btn_fechar_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
        }

        private void btn_salvar_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmb_tipo.Text == "")
                {
                    lbl_erro.Text = "Tipo";
                    pnl_error.Visible = true;
                }
                else
                {
                    if (txt_data.MaskFull == false)
                    {
                        lbl_erro.Text = "Data";
                        pnl_error.Visible = true;
                    }
                    else
                    {

                        if (cmb_bonus.Text == "")
                        {
                            lbl_erro.Text = "Bonus";
                            pnl_error.Visible = true;
                        }
                        else
                        {
                            string total = txt_final.Text.Replace(',', '.');
                            if (cmb_bonus.Text == "Sim")
                            {
                                bonus = true;
                            }
                            else
                            {
                                bonus = false;
                            }
                            if (rdbtn_pago.Checked)
                            {
                                compra.alterarCompra(total, cmb_tipo.Text, DateTime.Parse(txt_data.Text), "Pago", 1, bonus, id);
                            }
                            else
                            {
                                compra.alterarCompra(total, cmb_tipo.Text, DateTime.Parse(txt_data.Text), "Não Pago", 1, bonus, id);
                            }
                            MessageBox.Show("Alterado com sucesso");
                            Dispose();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmb_bonus_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(bonus_original == true)
            {
                if (cmb_bonus.SelectedIndex == 0)
                {
                    double value = original;
                    txt_final.Text = String.Format("{0:0.00}", value);
                }
                else
                {
                    double value = original *1.1;
                    txt_final.Text = String.Format("{0:0.00}", value);
                }
            }
            else
            {
                if (cmb_bonus.SelectedIndex == 0)
                {
                    double value = original * 0.9;
                    txt_final.Text = String.Format("{0:0.00}", value);
                }
                else
                {
                    double value = original;
                    txt_final.Text = String.Format("{0:0.00}", value);
                }
            }
        }
    }
}
