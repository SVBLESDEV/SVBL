﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Soluções_Enfermagem
{
    public partial class Curso : Form
    {
        public int num_curso;
        public string nome;
        public string valor;
        public int carga;
        public string inicio;
        public string fim;
        cmdCurso curso = new cmdCurso();
        public Curso()
        {
            InitializeComponent();
        }

        private void btn_atualizar_Click(object sender, EventArgs e)
        {
            MySqlDataReader temp = this.curso.listarCursos();
            DataTable dt = new DataTable();
            dt.Load(temp);
            table.DataSource = dt;
            this.curso.fech();
        }

        private void btn_adicionar_Click(object sender, EventArgs e)
        {
            Adicionar_Curso curso = new Adicionar_Curso();
            curso.ShowDialog();
        }

        private void btn_excluir_Click(object sender, EventArgs e)
        {
            if ((txt_alterar.Text == "{txt}") || (txt_alterar.Text == "Selecione um curso"))
            {
                txt_alterar.Text = "Selecione um curso";
                txt_alterar.Visible = true;
            }
            else
            {
                new Excluir_Curso(num_curso, nome, valor, carga, inicio, fim).ShowDialog();
                MySqlDataReader temp = this.curso.listarCursos();
                DataTable dt = new DataTable();
                dt.Load(temp);
                table.DataSource = dt;
                this.curso.fech();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if ((txt_alterar.Text == "{txt}") || (txt_alterar.Text == "Selecione um curso"))
            {
                txt_alterar.Text = "Selecione um curso";
                txt_alterar.Visible = true;
            }
            else
            {
                new Editar_Curso(num_curso, nome, valor, carga, inicio, fim).ShowDialog();
            }
        }

        private void Curso_Load(object sender, EventArgs e)
        {
            MySqlDataReader temp = this.curso.listarCursos();
            DataTable dt = new DataTable();
            dt.Load(temp);
            table.DataSource = dt;
            this.curso.fech();
        }

        private void table_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataGridViewRow linha = table.Rows[e.RowIndex];
                txt_alterar.Text = linha.Cells[0].Value.ToString();
                num_curso = int.Parse(linha.Cells[0].Value.ToString());
                nome = linha.Cells[1].Value.ToString();
                valor = linha.Cells[2].Value.ToString();
                valor = valor.Replace(',', '.');
                carga = int.Parse(linha.Cells[3].Value.ToString());
                inicio = linha.Cells[4].Value.ToString();
                fim = linha.Cells[5].Value.ToString();
                txt_alterar.Visible = true;
            }
            catch (Exception ex)
            {

            }
        }

        private void btn_pesquisar_Click(object sender, EventArgs e)
        {
            List<string> filtro = new List<string>();
            if (txt_codigo.Text != "")
            {
                filtro.Add("num_curso = '" + txt_codigo.Text + "'");
            }
            if (txt_nome.Text != "")
            {
                filtro.Add("nome like '%" + txt_nome.Text + "%'");
            }
            if (txt_cargahoraria.Text != "")
            {
                filtro.Add("carga_horaria = '" + txt_cargahoraria.Text + "'");
            }
            if (txt_valor.Text != "")
            {
                filtro.Add("valor = '" + txt_valor.Text + "'");
            }
            if (txt_inicio.MaskFull == true)
            {
                filtro.Add("periodo_inicio = '" + txt_inicio.Text.Substring(6) + "-" + txt_inicio.Text.Substring(3, 2) + "-" + txt_inicio.Text.Substring(0, 2) + "';");
            }
            if (txt_fim.MaskFull == true)
            {
                filtro.Add("periodo_fim= '" + txt_fim.Text.Substring(6) + "-" + txt_fim.Text.Substring(3, 2) + "-" + txt_fim.Text.Substring(0, 2) + "'");
            }
            if (filtro.Count != 0)
            {
                string pesquisa = String.Join("and ", filtro.ToArray());
                try
                {
                    MySqlDataReader temp = this.curso.pesquisarCurso(pesquisa);
                    DataTable dt = new DataTable();
                    dt.Load(temp);
                    table.DataSource = dt;
                    this.curso.fech();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
