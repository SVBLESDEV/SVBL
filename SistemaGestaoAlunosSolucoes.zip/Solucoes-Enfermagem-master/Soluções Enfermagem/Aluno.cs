﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Soluções_Enfermagem
{
    public partial class Aluno : Form
    {
        private cmdAluno aluno = new cmdAluno();
        private int num_aluno { get; set; }
        private string nome { get; set; }
        private int idade { get; set; }
        private string sexo { get; set; }
        private string rg { get; set; }
        private string cpf { get; set; }
        public Aluno()
        {
            InitializeComponent();
        }

        private void btn_adicionar_Click(object sender, EventArgs e)
        {
            Adicionar_Aluno add = new Adicionar_Aluno();
            add.ShowDialog();
        }

        private void btn_editar_Click(object sender, EventArgs e)
        {
            if ((txt_alterar.Text == "{txt}") || (txt_alterar.Text == "Selecione um aluno"))
            {
                txt_alterar.Text = "Selecione um aluno";
                txt_alterar.Visible = true;
            }
            else
            {
                new Editar_Aluno(num_aluno, nome, idade, sexo, rg, cpf).ShowDialog();
            }
        }

        private void btn_excluir_Click(object sender, EventArgs e)
        {
            if ((txt_alterar.Text == "{txt}") || (txt_alterar.Text == "Selecione um aluno"))
            {
                txt_alterar.Text = "Selecione um aluno";
                txt_alterar.Visible = true;
            }
            else
            {
                Excluir_Aluno aluno = new Excluir_Aluno(num_aluno, nome, idade, sexo, rg, cpf);
                aluno.ShowDialog();
                MySqlDataReader temp = this.aluno.listarAlunos();
                DataTable dt = new DataTable();
                dt.Load(temp);
                table.DataSource = dt;
                this.aluno.fech();
            }
        }

        private void Aluno_Load(object sender, EventArgs e)
        {
            MySqlDataReader temp = this.aluno.listarAlunos();
            DataTable dt = new DataTable();
            dt.Load(temp);
            table.DataSource = dt;
            this.aluno.fech();
        }

        private void btn_atualizar_Click(object sender, EventArgs e)
        {
            MySqlDataReader temp = this.aluno.listarAlunos();
            DataTable dt = new DataTable();
            dt.Load(temp);
            table.DataSource = dt;
            this.aluno.fech();
        }

        private void table_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataGridViewRow linha = table.Rows[e.RowIndex];
                txt_alterar.Text = linha.Cells[0].Value.ToString();
                num_aluno = int.Parse(linha.Cells[0].Value.ToString());
                nome = linha.Cells[1].Value.ToString();
                idade = int.Parse(linha.Cells[2].Value.ToString());
                sexo = linha.Cells[3].Value.ToString();
                rg = linha.Cells[4].Value.ToString();
                cpf = linha.Cells[5].Value.ToString();
                txt_alterar.Visible = true;
            }catch(Exception ex)
            {

            }
        }

        private void btn_visualizar_Click(object sender, EventArgs e)
        {
            if ((txt_alterar.Text == "{txt}") || (txt_alterar.Text == "Selecione um aluno"))
            {
                txt_alterar.Text = "Selecione um contato";
                txt_alterar.Visible = true;
            }
            else
            {
                new Visualizar_Aluno(num_aluno, nome, idade, sexo, rg, cpf).ShowDialog();
            }
        }

        private void btn_pesquisar_Click(object sender, EventArgs e)
        {
            List<string> filtro = new List<string>();
            if (txt_codigo.Text != "")
            {
                filtro.Add("num_aluno = '"+txt_codigo.Text+"'");
            }
            if(txt_nome.Text != "")
            {
                filtro.Add("nome like '%" + txt_nome.Text + "%'");
            }
            if (txt_cep.MaskFull == true)
            {
                filtro.Add("cep = '" + txt_cep.Text + "'");
            }
            if (txt_celular.MaskFull == true)
            {
                filtro.Add("celular = '" + txt_celular.Text + "'");
            }
            if (txt_cpf.MaskFull == true)
            {
                filtro.Add("cpf = '" + txt_cpf.Text + "'");
            }
            if (cmb_sexo.Text != "")
            {
                filtro.Add("sexo = '" + cmb_sexo.Text + "'");
            }
            if(filtro.Count != 0)
            {
                string pesquisa = String.Join("and ", filtro.ToArray());
                try
                {
                    MySqlDataReader temp = this.aluno.pequisarAlunos(pesquisa);
                    DataTable dt = new DataTable();
                    dt.Load(temp);
                    table.DataSource = dt;
                    this.aluno.fech();
 
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void table_DoubleClick(object sender, EventArgs e){}
        private void table_CellContentDoubleClick_1(object sender, DataGridViewCellEventArgs e){}
    }
}
