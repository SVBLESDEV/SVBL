﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Soluções_Enfermagem
{
    internal class Banco
    {
        private string host = "localhost";
        private string database = "solucoes_enfermagem";
        private string user = "root";
        private string password = "root";
        private MySqlConnection con;
        private MySqlCommand cmd;
        public Banco()
        {
        }
        public void conectar()
        {
            string strCon = @"server=" + this.host + "; database=" + this.database + "; user=" + this.user + "; password=" + this.password + "; port=3309;";
            this.con = new MySqlConnection(strCon);
            this.cmd = this.con.CreateCommand();
            this.con.Open();
        }
        public void close()
        {
            this.con.Close();
        }
        public void nonQuery(string sql)
        {
            this.cmd.CommandText = sql;
            this.cmd.ExecuteNonQuery();
        }
        public MySqlDataReader Query(string sql)
        {
            this.cmd.CommandText = sql;
            return this.cmd.ExecuteReader();
        }
    }
}


