﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Soluções_Enfermagem
{
    internal class cmdAluno
    {
        public int num_aluno { get; set; }
        public string nome { get; set; }
        public int idade { get; set; }
        public string sexo { get; set; }
        public string rg { get; set; }
        public string cpf { get; set; }
        public string bonus { get; set; }
        public int num_contato { get; set; }
        public string celular { get; set; }
        public string telefone { get; set; }
        public string email { get; set; }
        public int num_endereco { get; set; }
        public string cep { get; set; }
        public string rua { get; set; }
        public int numero { get; set; }
        public string bairro { get; set; }
        public string estado { get; set; }
        public string municipio { get; set; }
        public Banco banco = new Banco();

        public cmdAluno()
        {

        }

        public void fech()
        {
            this.banco.close();
        }

        public MySqlDataReader listarAlunos()
        {
            this.banco.conectar();
            return this.banco.Query("select num_aluno 'Codigo', nome 'Nome', idade 'Idade', sexo 'Sexo', rg 'RG', cpf 'CPF' from aluno;");
        }
         
        public MySqlDataReader pequisarAlunos(string filtro)
        {
            this.banco.conectar();
            return this.banco.Query("select num_aluno 'Codigo', nome 'Nome', idade 'Idade', sexo 'Sexo', rg 'RG', cpf 'CPF' from aluno a, endereco e, contato c where a.num_endereco=e.num_endereco and a.num_contato=c.num_contato and " + filtro + ";");
        }
        public string pequisarCurso(int id)
        {
            string nome = "";
            this.banco.conectar();
            MySqlDataReader reader = this.banco.Query("select nome from curso where num_curso = '" + id + "';");
            while (reader.Read())
            {
                nome = reader.GetString(0);
            }
            return nome;
        }
        private void cadastrarAluno() 
        {
            MySqlDataReader reader;
            this.banco.conectar();
            this.banco.nonQuery("insert into contato (celular,telefone,email)  values ('" + this.celular + "', '" + this.telefone + "', '" + this.email + "');");
            reader = this.banco.Query("select * from contato where celular = '" + this.celular + "' and telefone = '" + this.telefone + "' and email = '" + this.email + "';");
            reader.Read();
            int contato = reader.GetInt32(0);
            this.banco.close();
            this.banco.conectar();
            this.banco.nonQuery("insert into endereco (cep,rua,numero,bairro,estado,municipio)  values ('" + this.cep + "', '" + this.rua + "', '" + this.numero + "', '" + this.bairro + "', '" + this.estado + "', '" + this.municipio + "')");
            reader = this.banco.Query("select * from endereco where cep = '" + this.cep + "' and rua = '" + this.rua + "' and numero = '" + this.numero + "' and bairro = '" + this.bairro + "' and estado = '" + this.estado + "' and municipio = '" + this.municipio + "';");
            reader.Read();
            int endereco = reader.GetInt32(0);
            this.banco.close();
            this.banco.conectar();
            this.banco.nonQuery("insert into aluno (nome,idade,sexo,rg,cpf,bonus,num_contato,num_endereco)  values ('" + this.nome + "', '" + this.idade + "', '"+this.sexo+ "', '" + this.rg + "', '" + this.cpf + "', 'Não','"+contato+"', '"+endereco+"')");
            this.banco.close();
        }
        public void inserirAluno(string nome, int idade, string sexo, string rg, string cpf, string celular, string telefone, string email, string cep, string rua, int numero, string bairro, string estado, string municipio)
        {
            this.nome = nome;
            this.idade = idade;
            this.sexo = sexo;
            this.rg = rg;
            this.cpf = cpf;
            this.celular = celular;
            this.telefone = telefone;
            this.email = email;
            this.cep = cep;
            this.rua = rua;
            this.numero = numero;
            this.bairro = bairro;
            this.estado = estado;
            this.municipio = municipio;
            cadastrarAluno();
        }
        public void inserirAlunoAchar(int id, string n, int i, string s, string rg, string c)
        {
            this.num_aluno = id;
            this.nome = n;
            this.idade = i;
            this.sexo= s;
            this.rg= rg;
            this.cpf = c;
            this.banco.conectar();
            MySqlDataReader reader = this.banco.Query("select num_contato, num_endereco from aluno where num_aluno = '" + id + "'");
            while (reader.Read())
            {
                this.num_contato = reader.GetInt32(0);
                this.num_endereco = reader.GetInt32(1);
            }
            this.banco.close();
            this.banco.conectar();
            reader = this.banco.Query("select * from contato where num_contato = '" + this.num_contato + "'");
            while (reader.Read())
            {
                this.celular = reader.GetString(1);
                this.telefone = reader.GetString(2);
                this.email = reader.GetString(3);
            }
            this.banco.close();
            this.banco.conectar();
            reader = this.banco.Query("select * from endereco where num_endereco = '" + this.num_endereco + "'");
            while (reader.Read())
            {
                this.cep = reader.GetString(1);;
                this.rua = reader.GetString(2);
                this.numero = reader.GetInt32(3);
                this.bairro = reader.GetString(4);
                this.estado = reader.GetString(5);
                this.municipio = reader.GetString(6);
            }
            this.banco.close();
        }
        public void alterarAluno()
        {
            this.banco.conectar();
            this.banco.nonQuery("update contato set telefone = '" + this.telefone + "', celular = '" + this.celular + "', email = '" + this.email + "' where num_contato = '" + this.num_contato + "';");
            this.banco.close();
            this.banco.conectar();
            this.banco.nonQuery("update endereco set cep = '" + this.cep + "', rua = '" + this.rua + "', numero = '" + this.numero + "', bairro = '" + this.bairro + "', estado = '" + this.estado + "', municipio = '" + this.municipio + "' where num_endereco = '" + this.num_endereco + "';");
            this.banco.close();
            this.banco.conectar();
            this.banco.nonQuery("update aluno set nome = '" + this.nome + "', idade = '" + this.idade + "', sexo = '"+this.sexo+"', rg = '" + this.rg + "', cpf = '" + this.cpf + "' where num_aluno = '" + this.num_aluno + "';");
            this.banco.close();
        }
        public void excluirAluno(int id)
        {
            this.banco.conectar();
            this.banco.nonQuery("delete from aluno where num_aluno = '"+id+"'");
            this.banco.close();
        }
        public MySqlDataReader cursosAluno(int cod)
        {
            this.banco.conectar();
            return this.banco.Query("select c.num_curso 'Codigo', c.nome 'Nome', valor 'Valor', data_inscricao 'Data Inscricao', periodo_inicio 'Inicio', periodo_fim 'Fim' from curso c, aluno a, compra co, inscricao i where a.num_aluno='"+cod+ "' and a.num_aluno=co.num_aluno and co.num_curso=c.num_curso and i.num_aluno=co.num_aluno and i.num_curso=co.num_curso;");
        }
        public List<(string,string,string, string)> acharParcelas(string num, string nome)
        {
            List<(string,string,string, string)> list = new List<(string,string,string, string)> ();
            this.banco.conectar();
            MySqlDataReader reader = this.banco.Query("select pagamento_efetuado, data_pagamento, tipo_pagamento, status from compra c, aluno a, curso cu where c.num_aluno = a.num_aluno and c.num_curso = cu.num_curso and cu.num_curso='" + num+"' and a.nome='"+nome+"'; ");
            while (reader.Read())
            {
                list.Add((reader.GetString(0), reader.GetString(1), reader.GetString(2), reader.GetString(3)));
            }
            return list;
        }
        public (string,string) dataCursos(string num)
        {
            (string, string) datas = ("","");
            this.banco.conectar();
            MySqlDataReader reader = this.banco.Query("select periodo_inicio, periodo_fim from curso where num_curso='" + num + "'; ");
            while (reader.Read())
            {
                datas.Item1 = reader.GetString(0);
                datas.Item2 = reader.GetString(1);
            }
            return datas;
        }
        public string dataInscrição(string num, int id)
        {
            string insc="";
            this.banco.conectar();
            MySqlDataReader reader = this.banco.Query("select data_inscricao from inscricao where num_curso='" + num + "' and num_aluno='"+id+"'; ");
            while (reader.Read())
            {
                insc = reader.GetString(0);
            }
            return insc;
        }
    }
}
