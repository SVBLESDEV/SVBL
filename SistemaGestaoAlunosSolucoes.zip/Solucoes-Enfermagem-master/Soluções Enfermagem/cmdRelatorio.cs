﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Soluções_Enfermagem
{
    internal class cmdRelatorio
    {
        Banco banco = new Banco();
        public cmdRelatorio()
        {

        }
        public void fech()
        {
            this.banco.close();
        }
        public MySqlDataReader relatorioTotal()
        {
            this.banco.conectar();
            return this.banco.Query("select num_aluno 'Codigo', nome 'Nome', idade 'Idade', sexo 'Sexo', rg 'RG', cpf 'CPF', if(num_aluno in (select a.num_aluno from aluno a, compra c where a.num_aluno = c.num_aluno and status = 'Não Pago'),'Endividado','Não Endividado') 'Status' from aluno order by num_aluno desc;");
        }
        public MySqlDataReader numEndivida()
        {
            this.banco.conectar();
            return this.banco.Query("select count(num_aluno) from aluno where num_aluno in (select a.num_aluno from aluno a, compra c where a.num_aluno = c.num_aluno and status = 'Não Pago');");
        }
        public MySqlDataReader numAlunos()
        {
            this.banco.conectar();
            return this.banco.Query("select count(num_aluno) from aluno;");
        }
        public MySqlDataReader pequisarAlunos(string filtro)
        {
            this.banco.conectar();
            return this.banco.Query("select num_aluno 'Codigo', nome 'Nome', idade 'Idade', sexo 'Sexo', rg 'RG', cpf 'CPF', if(num_aluno in (select a.num_aluno from aluno a, compra c where a.num_aluno = c.num_aluno and status = 'Não Pago'),'Endividado','Não Endividado') 'Status' from aluno where " + filtro + ";");
        }
        public MySqlDataReader relatorioCurso(int num_curso)
        {
            this.banco.conectar();
            return this.banco.Query("select DISTINCT a.num_aluno 'Codigo', a.nome 'Nome', idade 'Idade', sexo 'Sexo', rg 'RG', cpf 'CPF', if(a.num_aluno in (select a.num_aluno from aluno a, compra c where a.num_aluno = c.num_aluno and status = 'Não Pago'),'Endividado','Não Endividado') 'Status' from aluno a, curso cu, compra c where a.num_aluno=c.num_aluno and cu.num_curso="+num_curso+" and c.num_curso=cu.num_curso;");
        }
        public MySqlDataReader numEndividaCurso(int num_curso)
        {
            this.banco.conectar();
            return this.banco.Query("select count(distinct a.num_aluno) from aluno a, curso cu, compra c where cu.num_curso=" + num_curso + " and a.num_aluno=c.num_aluno and c.num_curso=cu.num_curso and a.num_aluno in (select a.num_aluno from aluno a, compra c where a.num_aluno = c.num_aluno and status = 'Não Pago');");
        }
        public MySqlDataReader numAlunosCurso(int num_curso)
        {
            this.banco.conectar();
            return this.banco.Query("select count(distinct a.num_aluno) from aluno a, curso cu, compra c where cu.num_curso="+num_curso+" and a.num_aluno=c.num_aluno and c.num_curso=cu.num_curso;");
        }
        public MySqlDataReader acharCurso(int num_curso)
        {
            this.banco.conectar();
            return this.banco.Query("select nome from curso where num_curso = "+num_curso+";");
        }
        public MySqlDataReader pequisarAlunosCurso(string filtro)
        {
            this.banco.conectar();
            return this.banco.Query("select a.num_aluno 'Codigo', a.nome 'Nome', idade 'Idade', sexo 'Sexo', rg 'RG', cpf 'CPF', if(a.num_aluno in (select a.num_aluno from aluno a, compra c where a.num_aluno = c.num_aluno and status = 'Não Pago'),'Endividado','Não Endividado') 'Status' from aluno a, curso cu, compra c where a.num_aluno=c.num_aluno and c.num_curso=cu.num_curso and " + filtro + ";");
        }
    }
}
