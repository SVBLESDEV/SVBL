﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Soluções_Enfermagem
{
    public partial class Visualizar_Funcionario : Form
    {
        private int id;
        cmdFuncionario func = new cmdFuncionario();
        public Visualizar_Funcionario(int num_func, string nome, string cargo, string cpf)
        {
            InitializeComponent();
            id = num_func;
            txt_nome.Text = nome;
            txt_cpf.Text = cpf;
            txt_cargo.Text = cargo;
            func.inserirFuncionarioAchar(num_func, nome, cargo, cpf);
            txt_telefone.Text = func.telefone;
            txt_celular.Text = func.celular;
            txt_email.Text = func.email;
            txt_cep.Text = func.cep;
            txt_estado.Text = func.estado;
            txt_municipio.Text = func.municipio;
            txt_bairro.Text = func.bairro;
            txt_rua.Text = func.rua;
            txt_numero.Text = func.numero.ToString();
            func.fech();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void btn_fechar_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
