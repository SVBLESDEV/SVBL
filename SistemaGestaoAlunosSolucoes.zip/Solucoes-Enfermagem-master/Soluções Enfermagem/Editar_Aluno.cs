﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Soluções_Enfermagem
{
    public partial class Editar_Aluno : Form
    {
        private int id;
        cmdAluno aluno = new cmdAluno();

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd,
                         int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        public Editar_Aluno(int num_aluno, string nome, int idade, string sexo, string rg, string cpf)
        {
            InitializeComponent();
            id = num_aluno;
            txt_nome.Text = nome;
            txt_idade.Text = idade.ToString();
            txt_cpf.Text = cpf;
            txt_rg.Text = rg;
            cmb_sexo.Text = sexo;
            aluno.inserirAlunoAchar(num_aluno, nome, idade, sexo, rg, cpf);
            txt_telefone.Text = aluno.telefone;
            txt_celular.Text = aluno.celular;
            txt_email.Text = aluno.email;
            txt_cep.Text = aluno.cep;
            txt_estado.Text = aluno.estado;
            txt_municipio.Text = aluno.municipio;
            txt_bairro.Text = aluno.bairro;
            txt_rua.Text = aluno.rua;
            txt_numero.Text = aluno.numero.ToString();
            aluno.fech();
        }
        private void btn_delete_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void btn_fechar_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
        }

        private void btn_salvar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_nome.Text == "")
                {
                    lbl_erro.Text = "   Nome";
                    pnl_error.Visible = true;
                }
                else
                {
                    if (txt_idade.Text == "")
                    {
                        lbl_erro.Text = "  Idade";
                        pnl_error.Visible = true;
                    }
                    else
                    {
                        if ((txt_cpf.MaskFull == false) && (txt_rg.Text == ""))
                        {
                            lbl_erro.Text = "CPF/RG";
                            pnl_error.Visible = true;
                        }
                        else
                        {
                            if (txt_cep.MaskFull == false)
                            {
                                lbl_erro.Text = "    CEP";
                                pnl_error.Visible = true;
                            }
                            else
                            {
                                if (txt_numero.Text == "")
                                {
                                    txt_numero.Text = "0";
                                    if (txt_telefone.MaskFull || txt_celular.MaskFull || txt_email.Text != "")
                                    {
                                        aluno.nome = txt_nome.Text;
                                        aluno.idade = int.Parse(txt_idade.Text);
                                        aluno.sexo = cmb_sexo.Text;
                                        aluno.rg = txt_rg.Text;
                                        aluno.cpf = txt_cpf.Text;
                                        aluno.telefone = txt_telefone.Text;
                                        aluno.celular = txt_celular.Text;
                                        aluno.email = txt_email.Text;
                                        aluno.cep = txt_cep.Text;
                                        aluno.estado = txt_estado.Text;
                                        aluno.municipio = txt_municipio.Text;
                                        aluno.bairro = txt_bairro.Text;
                                        aluno.rua = txt_rua.Text;
                                        aluno.numero = int.Parse(txt_numero.Text);
                                        aluno.alterarAluno();
                                        MessageBox.Show("Editado com sucesso");
                                        Dispose();
                                    }
                                    else
                                    {
                                        lbl_erro.Text = "Contato";
                                        pnl_error.Visible = true;
                                    }
                                }
                                else
                                {
                                    if (txt_telefone.MaskFull || txt_celular.MaskFull || txt_email.Text != "")
                                    {
                                        aluno.nome = txt_nome.Text;
                                        aluno.idade = int.Parse(txt_idade.Text);
                                        aluno.sexo = cmb_sexo.Text;
                                        aluno.rg = txt_rg.Text;
                                        aluno.cpf = txt_cpf.Text;
                                        aluno.telefone = txt_telefone.Text;
                                        aluno.celular = txt_celular.Text;
                                        aluno.email = txt_email.Text;
                                        aluno.cep = txt_cep.Text;
                                        aluno.estado = txt_estado.Text;
                                        aluno.municipio = txt_municipio.Text;
                                        aluno.bairro = txt_bairro.Text;
                                        aluno.rua = txt_rua.Text;
                                        aluno.numero = int.Parse(txt_numero.Text);
                                        aluno.alterarAluno();
                                        MessageBox.Show("Editado com sucesso");
                                        Dispose();
                                    }
                                    else
                                    {
                                        lbl_erro.Text = "Contato";
                                        pnl_error.Visible = true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btn_delete_Click_1(object sender, EventArgs e)
        {
            Dispose();
        }

        private void panel2_Paint(object sender, PaintEventArgs e){}
    }
}
