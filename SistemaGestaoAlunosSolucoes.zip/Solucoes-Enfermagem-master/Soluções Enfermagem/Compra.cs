﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Soluções_Enfermagem
{
    public partial class Compra : Form
    {
        public int cod;
        public string aluno;
        public string curso;
        public string bonus;
        public string status;
        public string total;
        public string tipo;
        public string data;
        public string valor;
        bool flag;
        cmdCompra compra = new cmdCompra();
        Form currentChildForm;
        public Compra()
        {
            InitializeComponent();
            flag=false;
            openChildForm(new Compra_Curso());
        }
        public void idCompra(int i){}
        private void textBox1_TextChanged(object sender, EventArgs e){}
        private void btn_compra_atualizar_Click(object sender, EventArgs e){}
        private void openChildForm(Form childForm)
        {
            if(currentChildForm != null)
            {
                currentChildForm.Close();
            }
            currentChildForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panel_conteudo.Controls.Add(childForm);
            childForm.BringToFront();
            childForm.Show();
        }

        private void btn_comprar_Click(object sender, EventArgs e){}

        private void panel_conteudo_Click(object sender, EventArgs e){}

        private void btn_editar_Click(object sender, EventArgs e)
        {
            if ((txt_alterar.Text == "{txt}") || (txt_alterar.Text == "Selecione um registro"))
            {
                txt_alterar.Text = "Selecione um registro";
                txt_alterar.Visible = true;
            }
            else
            {
                Editar_Compra edit = new Editar_Compra(cod, aluno, curso, total, tipo, data, valor, bonus, status);
                edit.ShowDialog();
            }
        }

        private void btn_excluir_Click(object sender, EventArgs e)
        {
            if ((txt_alterar.Text == "{txt}") || (txt_alterar.Text == "Selecione um registro"))
            {
                txt_alterar.Text = "Selecione um registro";
                txt_alterar.Visible = true;
            }
            else
            {
                Excluir_Compra edit = new Excluir_Compra(cod, aluno, curso, total, tipo, data, valor,  bonus, status);
                edit.ShowDialog();
                if(flag == false)
                {
                    MySqlDataReader temp = this.compra.listarCompras();
                    DataTable dt = new DataTable();
                    dt.Load(temp);
                    table.DataSource = dt;
                    this.compra.fech();
                }
            }            
        }

        private void tabPage2_Enter(object sender, EventArgs e)
        {
            MySqlDataReader temp = this.compra.listarCompras();
            DataTable dt = new DataTable();
            dt.Load(temp);
            table.DataSource = dt;
            this.compra.fech();
        }

        private void btn_compra_atualizar_Click_1(object sender, EventArgs e)
        {
            MySqlDataReader temp = this.compra.listarCompras();
            DataTable dt = new DataTable();
            dt.Load(temp);
            table.DataSource = dt;
            this.compra.fech();
            flag = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            List<string> filtro = new List<string>();
            if (txt_codigo.Text != "")
            {
                filtro.Add("num_compra = '" + txt_codigo.Text + "'");
            }
            if (txt_aluno.Text != "")
            {
                filtro.Add("a.nome like '%" + txt_aluno.Text + "%'");
            }
            if (txt_valor.Text != "")
            {
                filtro.Add("valor_compra = '" + txt_valor.Text + "'");
            }
            if (txt_curso.Text != "")
            {
                filtro.Add("cu.nome = '" + txt_curso.Text + "'");
            }
            if (txt_total.Text != "")
            {
                filtro.Add("pagamento_efetuado = '" + txt_total.Text + "'");
            }
            if (txt_data.MaskFull == true)
            {
                filtro.Add("data_pagamento= '" + txt_data.Text.Substring(6) + "-" + txt_data.Text.Substring(3, 2) + "-" + txt_data.Text.Substring(0, 2) + "'");
            }
            if (filtro.Count != 0)
            {
                string pesquisa = String.Join("and ", filtro.ToArray());
                try
                {
                    MySqlDataReader temp = this.compra.pesquisarCompras(pesquisa);
                    DataTable dt = new DataTable();
                    dt.Load(temp);
                    table.DataSource = dt;
                    this.compra.fech();
                    flag = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void table_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataGridViewRow linha = table.Rows[e.RowIndex];
                txt_alterar.Text = linha.Cells[0].Value.ToString();
                cod = int.Parse(linha.Cells[0].Value.ToString());
                aluno = linha.Cells[1].Value.ToString();
                curso = linha.Cells[2].Value.ToString();
                total = linha.Cells[6].Value.ToString();
                tipo = linha.Cells[4].Value.ToString();
                data = linha.Cells[5].Value.ToString();
                valor = linha.Cells[3].Value.ToString();
                bonus = linha.Cells[7].Value.ToString();
                status = linha.Cells[8].Value.ToString();
                txt_alterar.Visible = true;
            }
            catch (Exception ex)
            {

            }
        }
    }
}
