﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Soluções_Enfermagem
{
    public partial class Parcelas : Form
    {
        public DateTime primeiro;
        public int intervalo;
        public string unidade;
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd,
                         int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        public Parcelas()
        {
            InitializeComponent();
        }
        public Parcelas(DateTime p, int i, string uni)
        {
            InitializeComponent();
            dt_primeiro.Value = p;
            txt_intervalo.Text = i.ToString();
            cmb_unidade.Text = uni;
        }

        private void btn_fechar_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private void btn_salvar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_intervalo.Text == "")
                {
                    lbl_erro.Text = "Parcelas";
                    pnl_error.Visible = true;
                }
                else
                {
                    if ((cmb_unidade.Text == "Dia")|| (cmb_unidade.Text == "Mês")|| (cmb_unidade.Text == "Ano"))
                    {
                        this.primeiro = dt_primeiro.Value;
                        this.intervalo = int.Parse(txt_intervalo.Text);
                        this.unidade = cmb_unidade.Text;
                        this.DialogResult = DialogResult.OK;
                        this.Close();
                    }
                    else
                    {
                        lbl_erro.Text = "Unidade";
                        pnl_error.Visible = true;
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
        }
    }
}
