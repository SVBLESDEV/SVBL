﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Soluções_Enfermagem
{
    internal class cmdFuncionario
    {
        public int num_func { get; set; }
        public string nome { get; set; }
        public string cargo { get; set; }
        public string coren { get; set; }
        public int num_contato { get; set; }
        public string celular { get; set; }
        public string telefone { get; set; }
        public string email { get; set; }
        public int num_endereco { get; set; }
        public string cep { get; set; }
        public string rua { get; set; }
        public int numero { get; set; }
        public string bairro { get; set; }
        public string estado { get; set; }
        public string municipio { get; set; }
        public Banco banco = new Banco();

        public cmdFuncionario()
        {

        }
        public void fech()
        {
            this.banco.close();
        }
        public MySqlDataReader listarFuncionarios()
        {
            this.banco.conectar();
            return this.banco.Query("select num_func 'Codigo', nome 'Nome', cargo 'Cargo', coren 'coren' from funcionario;");
        }
        private void cadastrarFuncionario()
        {
            MySqlDataReader reader;
            this.banco.conectar();
            this.banco.nonQuery("insert into contato (celular,telefone,email)  values ('" + this.celular + "', '" + this.telefone + "', '" + this.email + "')");
            reader = this.banco.Query("select * from contato where celular = '" + this.celular + "' and telefone = '" + this.telefone + "' and email = '" + this.email + "';");
            reader.Read();
            int contato = reader.GetInt32(0);
            this.banco.close();
            this.banco.conectar();
            this.banco.nonQuery("insert into endereco (cep,rua,numero,bairro,estado,municipio)  values ('" + this.cep + "', '" + this.rua + "', '" + this.numero + "', '" + this.bairro + "', '" + this.estado + "', '" + this.municipio + "')");
            reader = this.banco.Query("select * from endereco where cep = '" + this.cep + "' and rua = '" + this.rua + "' and numero = '" + this.numero + "' and bairro = '" + this.bairro + "' and estado = '" + this.estado + "' and municipio = '" + this.municipio + "';");
            reader.Read();
            int endereco = reader.GetInt32(0);
            this.banco.close();
            this.banco.conectar();
            this.banco.nonQuery("insert into funcionario (nome,cargo,coren,num_contato,num_endereco)  values ('" + this.nome + "', '" + this.cargo + "', '" + this.coren + "', '" + contato + "', '" + endereco + "')");
            this.banco.close();
        }
        public void inserirFuncionario(string nome, string cargo, string coren, string celular, string telefone, string email, string cep, string rua, int numero, string bairro, string estado, string municipio)
        {
            this.nome = nome;
            this.cargo = cargo;
            this.coren = coren;
            this.celular = celular;
            this.telefone = telefone;
            this.email = email;
            this.cep = cep;
            this.rua = rua;
            this.numero = numero;
            this.bairro = bairro;
            this.estado = estado;
            this.municipio = municipio;
            cadastrarFuncionario();
        }
        public void inserirFuncionarioAchar(int id, string n, string cargo, string c)
        {
            this.num_func = id;
            this.nome = n;
            this.cargo = cargo;
            this.coren = c;
            this.banco.conectar();
            MySqlDataReader reader = this.banco.Query("select num_contato, num_endereco from funcionario where num_func = '" + id + "'");
            if (reader.Read())
            {
                this.num_contato = reader.GetInt32(0);
                this.num_endereco = reader.GetInt32(1);
            }
            this.banco.close();
            this.banco.conectar();
            reader = this.banco.Query("select * from contato where num_contato = '" + this.num_contato + "'");
            if (reader.Read())
            {
                this.celular = reader.GetString(1);
                this.telefone = reader.GetString(2);
                this.email = reader.GetString(3);
            }
            this.banco.close();
            this.banco.conectar();
            reader = this.banco.Query("select * from endereco where num_endereco = '" + this.num_endereco + "'");
            if (reader.Read())
            {
                this.cep = reader.GetString(1); ;
                this.rua = reader.GetString(2);
                this.numero = reader.GetInt32(3);
                this.bairro = reader.GetString(4);
                this.estado = reader.GetString(5);
                this.municipio = reader.GetString(6);
            }
            this.banco.close();
        }
        public void alterarFuncionario()
        {
            this.banco.conectar();
            this.banco.nonQuery("update contato set telefone = '" + this.telefone + "', celular = '" + this.celular + "', email = '" + this.email + "' where num_contato = '" + this.num_contato + "';");
            this.banco.close();
            this.banco.conectar();
            this.banco.nonQuery("update endereco set cep = '" + this.cep + "', rua = '" + this.rua + "', numero = '" + this.numero + "', bairro = '" + this.bairro + "', estado = '" + this.estado + "', municipio = '" + this.municipio + "' where num_endereco = '" + this.num_endereco + "';");
            this.banco.close();
            this.banco.conectar();
            this.banco.nonQuery("update funcionario set nome = '" + this.nome + "', cargo = '" + this.cargo + "', coren = '" + this.coren + "' where num_func = '" + this.num_func + "';");
            this.banco.close();
        }
        public void excluirFuncionario(int id)
        {
            this.banco.conectar();
            this.banco.nonQuery("delete from funcionario where num_func = '" + id + "'");
            this.banco.close();
        }
        public MySqlDataReader pequisarFuncionario(string filtro)
        {
            this.banco.conectar();
            return this.banco.Query("select num_func 'Codigo', nome 'Nome', cargo 'Cargo', coren 'coren' from funcionario f, endereco e, contato c where f.num_endereco=e.num_endereco and f.num_contato=c.num_contato and " + filtro + ";");
        }
    }
}
