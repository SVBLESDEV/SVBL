﻿namespace Soluções_Enfermagem
{
    partial class frm_Menu_Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm_Menu_Principal));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_maximizar = new System.Windows.Forms.Button();
            this.btn_minimizar = new System.Windows.Forms.Button();
            this.btn_fechar = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_func = new System.Windows.Forms.Button();
            this.btn_compra = new System.Windows.Forms.Button();
            this.btn_sair = new System.Windows.Forms.Button();
            this.btn_relatorio = new System.Windows.Forms.Button();
            this.btn_cursos = new System.Windows.Forms.Button();
            this.btn_aluno = new System.Windows.Forms.Button();
            this.panel_conteudo = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(161)))), ((int)(((byte)(116)))));
            this.panel1.Controls.Add(this.btn_maximizar);
            this.panel1.Controls.Add(this.btn_minimizar);
            this.panel1.Controls.Add(this.btn_fechar);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1500, 45);
            this.panel1.TabIndex = 3;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            // 
            // btn_maximizar
            // 
            this.btn_maximizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_maximizar.FlatAppearance.BorderSize = 0;
            this.btn_maximizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_maximizar.Image = ((System.Drawing.Image)(resources.GetObject("btn_maximizar.Image")));
            this.btn_maximizar.Location = new System.Drawing.Point(1404, 0);
            this.btn_maximizar.Name = "btn_maximizar";
            this.btn_maximizar.Size = new System.Drawing.Size(45, 45);
            this.btn_maximizar.TabIndex = 2;
            this.btn_maximizar.UseVisualStyleBackColor = true;
            this.btn_maximizar.Click += new System.EventHandler(this.btn_maximizar_Click);
            // 
            // btn_minimizar
            // 
            this.btn_minimizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_minimizar.FlatAppearance.BorderSize = 0;
            this.btn_minimizar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_minimizar.Image = ((System.Drawing.Image)(resources.GetObject("btn_minimizar.Image")));
            this.btn_minimizar.Location = new System.Drawing.Point(1353, 0);
            this.btn_minimizar.Name = "btn_minimizar";
            this.btn_minimizar.Size = new System.Drawing.Size(45, 45);
            this.btn_minimizar.TabIndex = 1;
            this.btn_minimizar.UseVisualStyleBackColor = true;
            this.btn_minimizar.Click += new System.EventHandler(this.btn_minimizar_Click);
            // 
            // btn_fechar
            // 
            this.btn_fechar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_fechar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(161)))), ((int)(((byte)(116)))));
            this.btn_fechar.FlatAppearance.BorderColor = System.Drawing.Color.Goldenrod;
            this.btn_fechar.FlatAppearance.BorderSize = 0;
            this.btn_fechar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_fechar.ForeColor = System.Drawing.Color.Goldenrod;
            this.btn_fechar.Image = ((System.Drawing.Image)(resources.GetObject("btn_fechar.Image")));
            this.btn_fechar.Location = new System.Drawing.Point(1455, 0);
            this.btn_fechar.Name = "btn_fechar";
            this.btn_fechar.Size = new System.Drawing.Size(45, 45);
            this.btn_fechar.TabIndex = 1;
            this.btn_fechar.UseVisualStyleBackColor = false;
            this.btn_fechar.Click += new System.EventHandler(this.btn_fechar_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DimGray;
            this.panel2.Controls.Add(this.btn_func);
            this.panel2.Controls.Add(this.btn_compra);
            this.panel2.Controls.Add(this.btn_sair);
            this.panel2.Controls.Add(this.btn_relatorio);
            this.panel2.Controls.Add(this.btn_cursos);
            this.panel2.Controls.Add(this.btn_aluno);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 45);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(235, 755);
            this.panel2.TabIndex = 10;
            // 
            // btn_func
            // 
            this.btn_func.BackColor = System.Drawing.Color.DarkGray;
            this.btn_func.FlatAppearance.BorderSize = 0;
            this.btn_func.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_func.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_func.ForeColor = System.Drawing.Color.Black;
            this.btn_func.Image = ((System.Drawing.Image)(resources.GetObject("btn_func.Image")));
            this.btn_func.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_func.Location = new System.Drawing.Point(0, 178);
            this.btn_func.Name = "btn_func";
            this.btn_func.Size = new System.Drawing.Size(235, 84);
            this.btn_func.TabIndex = 17;
            this.btn_func.Text = "        Funcionario";
            this.btn_func.UseVisualStyleBackColor = false;
            this.btn_func.Click += new System.EventHandler(this.btn_func_Click);
            // 
            // btn_compra
            // 
            this.btn_compra.BackColor = System.Drawing.Color.DarkGray;
            this.btn_compra.FlatAppearance.BorderSize = 0;
            this.btn_compra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_compra.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_compra.ForeColor = System.Drawing.Color.Black;
            this.btn_compra.Image = ((System.Drawing.Image)(resources.GetObject("btn_compra.Image")));
            this.btn_compra.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_compra.Location = new System.Drawing.Point(0, 390);
            this.btn_compra.Name = "btn_compra";
            this.btn_compra.Size = new System.Drawing.Size(235, 84);
            this.btn_compra.TabIndex = 16;
            this.btn_compra.Text = "         Compra";
            this.btn_compra.UseVisualStyleBackColor = false;
            this.btn_compra.Click += new System.EventHandler(this.btn_compra_Click);
            // 
            // btn_sair
            // 
            this.btn_sair.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btn_sair.BackColor = System.Drawing.Color.DarkGray;
            this.btn_sair.FlatAppearance.BorderSize = 0;
            this.btn_sair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_sair.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_sair.Image = ((System.Drawing.Image)(resources.GetObject("btn_sair.Image")));
            this.btn_sair.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_sair.Location = new System.Drawing.Point(0, 671);
            this.btn_sair.Name = "btn_sair";
            this.btn_sair.Size = new System.Drawing.Size(235, 84);
            this.btn_sair.TabIndex = 15;
            this.btn_sair.Text = "         Sair";
            this.btn_sair.UseVisualStyleBackColor = false;
            this.btn_sair.Click += new System.EventHandler(this.btn_sair_Click);
            // 
            // btn_relatorio
            // 
            this.btn_relatorio.BackColor = System.Drawing.Color.DarkGray;
            this.btn_relatorio.FlatAppearance.BorderSize = 0;
            this.btn_relatorio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_relatorio.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_relatorio.Image = ((System.Drawing.Image)(resources.GetObject("btn_relatorio.Image")));
            this.btn_relatorio.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_relatorio.Location = new System.Drawing.Point(0, 496);
            this.btn_relatorio.Name = "btn_relatorio";
            this.btn_relatorio.Size = new System.Drawing.Size(235, 84);
            this.btn_relatorio.TabIndex = 13;
            this.btn_relatorio.Text = "         Relatorio";
            this.btn_relatorio.UseVisualStyleBackColor = false;
            this.btn_relatorio.Click += new System.EventHandler(this.btn_relatorio_Click);
            // 
            // btn_cursos
            // 
            this.btn_cursos.BackColor = System.Drawing.Color.DarkGray;
            this.btn_cursos.FlatAppearance.BorderSize = 0;
            this.btn_cursos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_cursos.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cursos.ForeColor = System.Drawing.Color.Black;
            this.btn_cursos.Image = ((System.Drawing.Image)(resources.GetObject("btn_cursos.Image")));
            this.btn_cursos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_cursos.Location = new System.Drawing.Point(0, 284);
            this.btn_cursos.Name = "btn_cursos";
            this.btn_cursos.Size = new System.Drawing.Size(235, 84);
            this.btn_cursos.TabIndex = 12;
            this.btn_cursos.Text = "         Cursos";
            this.btn_cursos.UseVisualStyleBackColor = false;
            this.btn_cursos.Click += new System.EventHandler(this.btn_cursos_Click);
            // 
            // btn_aluno
            // 
            this.btn_aluno.BackColor = System.Drawing.Color.DarkGray;
            this.btn_aluno.FlatAppearance.BorderSize = 0;
            this.btn_aluno.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_aluno.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_aluno.ForeColor = System.Drawing.Color.Black;
            this.btn_aluno.Image = ((System.Drawing.Image)(resources.GetObject("btn_aluno.Image")));
            this.btn_aluno.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_aluno.Location = new System.Drawing.Point(0, 72);
            this.btn_aluno.Name = "btn_aluno";
            this.btn_aluno.Size = new System.Drawing.Size(235, 84);
            this.btn_aluno.TabIndex = 11;
            this.btn_aluno.Text = "         Aluno";
            this.btn_aluno.UseVisualStyleBackColor = false;
            this.btn_aluno.Click += new System.EventHandler(this.btn_aluno_Click);
            // 
            // panel_conteudo
            // 
            this.panel_conteudo.BackColor = System.Drawing.Color.LightGray;
            this.panel_conteudo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_conteudo.Location = new System.Drawing.Point(235, 45);
            this.panel_conteudo.Name = "panel_conteudo";
            this.panel_conteudo.Size = new System.Drawing.Size(1265, 755);
            this.panel_conteudo.TabIndex = 11;
            // 
            // frm_Menu_Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1500, 800);
            this.Controls.Add(this.panel_conteudo);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frm_Menu_Principal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu_Principal";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_maximizar;
        private System.Windows.Forms.Button btn_minimizar;
        private System.Windows.Forms.Button btn_fechar;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btn_relatorio;
        private System.Windows.Forms.Button btn_cursos;
        private System.Windows.Forms.Button btn_aluno;
        private System.Windows.Forms.Panel panel_conteudo;
        private System.Windows.Forms.Button btn_sair;
        private System.Windows.Forms.Button btn_compra;
        private System.Windows.Forms.Button btn_func;
    }
}