﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Soluções_Enfermagem
{
    public partial class Excluir_Aluno : Form
    {
        private int id;
        cmdAluno aluno = new cmdAluno();

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd,
                         int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        public Excluir_Aluno(int num_aluno, string nome, int idade, string sexo, string rg, string cpf)
        {
            InitializeComponent();
            id = num_aluno;
            txt_nome.Text = nome;
            txt_idade.Text = idade.ToString();
            txt_cpf.Text = cpf;
            txt_rg.Text = rg;
            txt_sexo.Text = sexo;
            aluno.inserirAlunoAchar(num_aluno, nome, idade, sexo, rg, cpf);
            txt_telefone.Text = aluno.telefone;
            txt_celular.Text = aluno.celular;
            txt_email.Text = aluno.email;
            txt_cep.Text = aluno.cep;
            txt_estado.Text = aluno.estado;
            txt_municipio.Text = aluno.municipio;
            txt_bairro.Text = aluno.bairro;
            txt_rua.Text = aluno.rua;
            txt_numero.Text = aluno.numero.ToString();
            aluno.fech();
        }

        private void btn_fechar_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            try
            {
                aluno.excluirAluno(id);
                MessageBox.Show("Aluno Excluido");
                Dispose();
            }catch(Exception ex)
            {

            }
        }
    }
}
