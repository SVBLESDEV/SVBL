﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Soluções_Enfermagem
{
    public partial class Adicionar_Curso : Form
    {
        cmdCurso curso = new cmdCurso();
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd,
                         int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        public Adicionar_Curso()
        {
            InitializeComponent();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void btn_fechar_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
        }

        private void btn_salvar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txt_nome.Text == "")
                {
                    lbl_erro.Text = "      Nome";
                    pnl_error.Visible = true;
                }
                else
                {
                    if (txt_cargahoraria.Text == "")
                    {
                        lbl_erro.Text = "Carga Horaria";
                        pnl_error.Visible = true;
                    }
                    else
                    {
                        if (txt_valor.Text == "")
                        {
                            lbl_erro.Text = "       Valor";
                            pnl_error.Visible = true;
                        }
                        else
                        {
                           curso.inserirCurso(txt_nome.Text, int.Parse(txt_cargahoraria.Text), txt_valor.Text.Replace(',','.'), dt_inicio.Value.Year.ToString(), dt_inicio.Value.Month.ToString(), dt_inicio.Value.Day.ToString(), dt_fim.Value.Year.ToString(), dt_fim.Value.Month.ToString(), dt_fim.Value.Day.ToString());
                           MessageBox.Show("Adicionado com sucesso");
                           Dispose();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
