﻿namespace Soluções_Enfermagem
{
    partial class Adicionar_Compra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Adicionar_Compra));
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdbtn_naopago = new System.Windows.Forms.RadioButton();
            this.rdbtn_pago = new System.Windows.Forms.RadioButton();
            this.grp_parcelas = new System.Windows.Forms.GroupBox();
            this.btn_datas = new System.Windows.Forms.Button();
            this.cmb_quantidade = new System.Windows.Forms.ComboBox();
            this.rdbtn_nao = new System.Windows.Forms.RadioButton();
            this.rdbtn_sim = new System.Windows.Forms.RadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_final = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_valor = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cmb_bonus = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_data = new System.Windows.Forms.MaskedTextBox();
            this.cmb_tipo = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_curso = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pnl_error = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.lbl_erro = new System.Windows.Forms.Label();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_salvar = new System.Windows.Forms.Button();
            this.txt_aluno = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.btn_fechar = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.grp_parcelas.SuspendLayout();
            this.pnl_error.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.grp_parcelas);
            this.panel2.Controls.Add(this.rdbtn_nao);
            this.panel2.Controls.Add(this.rdbtn_sim);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.txt_final);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.txt_valor);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.cmb_bonus);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.txt_data);
            this.panel2.Controls.Add(this.cmb_tipo);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.txt_curso);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.pnl_error);
            this.panel2.Controls.Add(this.btn_delete);
            this.panel2.Controls.Add(this.btn_salvar);
            this.panel2.Controls.Add(this.txt_aluno);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.Location = new System.Drawing.Point(12, 45);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(689, 375);
            this.panel2.TabIndex = 7;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdbtn_naopago);
            this.groupBox1.Controls.Add(this.rdbtn_pago);
            this.groupBox1.Location = new System.Drawing.Point(442, 247);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(175, 62);
            this.groupBox1.TabIndex = 59;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Status";
            // 
            // rdbtn_naopago
            // 
            this.rdbtn_naopago.AutoSize = true;
            this.rdbtn_naopago.Checked = true;
            this.rdbtn_naopago.Location = new System.Drawing.Point(76, 25);
            this.rdbtn_naopago.Name = "rdbtn_naopago";
            this.rdbtn_naopago.Size = new System.Drawing.Size(97, 22);
            this.rdbtn_naopago.TabIndex = 1;
            this.rdbtn_naopago.TabStop = true;
            this.rdbtn_naopago.Text = "Não Pago";
            this.rdbtn_naopago.UseVisualStyleBackColor = true;
            this.rdbtn_naopago.CheckedChanged += new System.EventHandler(this.rdbtn_naopago_CheckedChanged);
            // 
            // rdbtn_pago
            // 
            this.rdbtn_pago.AutoSize = true;
            this.rdbtn_pago.Location = new System.Drawing.Point(6, 25);
            this.rdbtn_pago.Name = "rdbtn_pago";
            this.rdbtn_pago.Size = new System.Drawing.Size(64, 22);
            this.rdbtn_pago.TabIndex = 0;
            this.rdbtn_pago.Text = "Pago";
            this.rdbtn_pago.UseVisualStyleBackColor = true;
            this.rdbtn_pago.CheckedChanged += new System.EventHandler(this.rdbtn_pago_CheckedChanged);
            // 
            // grp_parcelas
            // 
            this.grp_parcelas.Controls.Add(this.btn_datas);
            this.grp_parcelas.Controls.Add(this.cmb_quantidade);
            this.grp_parcelas.Location = new System.Drawing.Point(136, 194);
            this.grp_parcelas.Name = "grp_parcelas";
            this.grp_parcelas.Size = new System.Drawing.Size(258, 75);
            this.grp_parcelas.TabIndex = 58;
            this.grp_parcelas.TabStop = false;
            this.grp_parcelas.Text = "Parcelas";
            this.grp_parcelas.Visible = false;
            // 
            // btn_datas
            // 
            this.btn_datas.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(169)))), ((int)(((byte)(79)))));
            this.btn_datas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_datas.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold);
            this.btn_datas.ForeColor = System.Drawing.Color.White;
            this.btn_datas.Location = new System.Drawing.Point(145, 26);
            this.btn_datas.Name = "btn_datas";
            this.btn_datas.Size = new System.Drawing.Size(93, 34);
            this.btn_datas.TabIndex = 61;
            this.btn_datas.Text = "Datas";
            this.btn_datas.UseVisualStyleBackColor = false;
            this.btn_datas.Click += new System.EventHandler(this.btn_datas_Click_1);
            // 
            // cmb_quantidade
            // 
            this.cmb_quantidade.FormattingEnabled = true;
            this.cmb_quantidade.ItemHeight = 18;
            this.cmb_quantidade.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.cmb_quantidade.Location = new System.Drawing.Point(12, 31);
            this.cmb_quantidade.Name = "cmb_quantidade";
            this.cmb_quantidade.Size = new System.Drawing.Size(121, 26);
            this.cmb_quantidade.TabIndex = 4;
            this.cmb_quantidade.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // rdbtn_nao
            // 
            this.rdbtn_nao.AutoSize = true;
            this.rdbtn_nao.Checked = true;
            this.rdbtn_nao.Location = new System.Drawing.Point(17, 247);
            this.rdbtn_nao.Name = "rdbtn_nao";
            this.rdbtn_nao.Size = new System.Drawing.Size(55, 22);
            this.rdbtn_nao.TabIndex = 55;
            this.rdbtn_nao.TabStop = true;
            this.rdbtn_nao.Text = "Não";
            this.rdbtn_nao.UseVisualStyleBackColor = true;
            this.rdbtn_nao.CheckedChanged += new System.EventHandler(this.rdbtn_nao_CheckedChanged);
            // 
            // rdbtn_sim
            // 
            this.rdbtn_sim.AutoSize = true;
            this.rdbtn_sim.Location = new System.Drawing.Point(17, 219);
            this.rdbtn_sim.Name = "rdbtn_sim";
            this.rdbtn_sim.Size = new System.Drawing.Size(54, 22);
            this.rdbtn_sim.TabIndex = 54;
            this.rdbtn_sim.TabStop = true;
            this.rdbtn_sim.Text = "Sim";
            this.rdbtn_sim.UseVisualStyleBackColor = true;
            this.rdbtn_sim.CheckedChanged += new System.EventHandler(this.rdbtn_sim_CheckedChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(17, 194);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 18);
            this.label9.TabIndex = 51;
            this.label9.Text = "Parcelado";
            // 
            // txt_final
            // 
            this.txt_final.Location = new System.Drawing.Point(442, 215);
            this.txt_final.Name = "txt_final";
            this.txt_final.ReadOnly = true;
            this.txt_final.Size = new System.Drawing.Size(219, 26);
            this.txt_final.TabIndex = 50;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(439, 194);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(82, 18);
            this.label8.TabIndex = 49;
            this.label8.Text = "Valor Final";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(17, 124);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(108, 18);
            this.label7.TabIndex = 48;
            this.label7.Text = "Valor do curso";
            // 
            // txt_valor
            // 
            this.txt_valor.Location = new System.Drawing.Point(17, 145);
            this.txt_valor.Name = "txt_valor";
            this.txt_valor.ReadOnly = true;
            this.txt_valor.Size = new System.Drawing.Size(219, 26);
            this.txt_valor.TabIndex = 47;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(549, 124);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 18);
            this.label5.TabIndex = 46;
            this.label5.Text = "Bonus";
            // 
            // cmb_bonus
            // 
            this.cmb_bonus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmb_bonus.FormattingEnabled = true;
            this.cmb_bonus.Items.AddRange(new object[] {
            "Sim",
            "Não"});
            this.cmb_bonus.Location = new System.Drawing.Point(552, 145);
            this.cmb_bonus.Name = "cmb_bonus";
            this.cmb_bonus.Size = new System.Drawing.Size(121, 26);
            this.cmb_bonus.TabIndex = 3;
            this.cmb_bonus.SelectedIndexChanged += new System.EventHandler(this.cmb_bonus_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(439, 124);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 18);
            this.label4.TabIndex = 44;
            this.label4.Text = "Data";
            // 
            // txt_data
            // 
            this.txt_data.Location = new System.Drawing.Point(442, 145);
            this.txt_data.Mask = "00/00/0000";
            this.txt_data.Name = "txt_data";
            this.txt_data.Size = new System.Drawing.Size(100, 26);
            this.txt_data.TabIndex = 2;
            this.txt_data.ValidatingType = typeof(System.DateTime);
            // 
            // cmb_tipo
            // 
            this.cmb_tipo.FormattingEnabled = true;
            this.cmb_tipo.Items.AddRange(new object[] {
            "Credito",
            "Debito",
            "Boleto",
            "Pix",
            "Picpay",
            "Dinheiro"});
            this.cmb_tipo.Location = new System.Drawing.Point(256, 145);
            this.cmb_tipo.Name = "cmb_tipo";
            this.cmb_tipo.Size = new System.Drawing.Size(168, 26);
            this.cmb_tipo.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(253, 124);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(121, 18);
            this.label1.TabIndex = 41;
            this.label1.Text = "Tipo pagamento";
            // 
            // txt_curso
            // 
            this.txt_curso.Location = new System.Drawing.Point(411, 75);
            this.txt_curso.Name = "txt_curso";
            this.txt_curso.ReadOnly = true;
            this.txt_curso.Size = new System.Drawing.Size(262, 26);
            this.txt_curso.TabIndex = 39;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(408, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 18);
            this.label3.TabIndex = 38;
            this.label3.Text = "Curso";
            // 
            // pnl_error
            // 
            this.pnl_error.BackColor = System.Drawing.Color.Tomato;
            this.pnl_error.Controls.Add(this.label6);
            this.pnl_error.Controls.Add(this.lbl_erro);
            this.pnl_error.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_error.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnl_error.Location = new System.Drawing.Point(0, 0);
            this.pnl_error.Name = "pnl_error";
            this.pnl_error.Size = new System.Drawing.Size(689, 41);
            this.pnl_error.TabIndex = 10;
            this.pnl_error.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(309, 11);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(152, 19);
            this.label6.TabIndex = 1;
            this.label6.Text = "não foi preenchido";
            // 
            // lbl_erro
            // 
            this.lbl_erro.AutoSize = true;
            this.lbl_erro.ForeColor = System.Drawing.Color.White;
            this.lbl_erro.Location = new System.Drawing.Point(262, 11);
            this.lbl_erro.Name = "lbl_erro";
            this.lbl_erro.Size = new System.Drawing.Size(40, 19);
            this.lbl_erro.TabIndex = 0;
            this.lbl_erro.Text = "{txt}";
            // 
            // btn_delete
            // 
            this.btn_delete.BackColor = System.Drawing.Color.Tomato;
            this.btn_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_delete.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.ForeColor = System.Drawing.Color.White;
            this.btn_delete.Location = new System.Drawing.Point(155, 320);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(132, 39);
            this.btn_delete.TabIndex = 7;
            this.btn_delete.Text = "Sair";
            this.btn_delete.UseVisualStyleBackColor = false;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_salvar
            // 
            this.btn_salvar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(169)))), ((int)(((byte)(79)))));
            this.btn_salvar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_salvar.Font = new System.Drawing.Font("Segoe UI Semibold", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_salvar.ForeColor = System.Drawing.Color.White;
            this.btn_salvar.Location = new System.Drawing.Point(17, 320);
            this.btn_salvar.Name = "btn_salvar";
            this.btn_salvar.Size = new System.Drawing.Size(132, 39);
            this.btn_salvar.TabIndex = 6;
            this.btn_salvar.Text = "Salvar";
            this.btn_salvar.UseVisualStyleBackColor = false;
            this.btn_salvar.Click += new System.EventHandler(this.btn_salvar_Click);
            // 
            // txt_aluno
            // 
            this.txt_aluno.Location = new System.Drawing.Point(17, 75);
            this.txt_aluno.Name = "txt_aluno";
            this.txt_aluno.ReadOnly = true;
            this.txt_aluno.Size = new System.Drawing.Size(377, 26);
            this.txt_aluno.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(14, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 18);
            this.label2.TabIndex = 0;
            this.label2.Text = "Aluno";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(161)))), ((int)(((byte)(116)))));
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.btn_fechar);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(713, 45);
            this.panel1.TabIndex = 6;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(12, 9);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(192, 24);
            this.label10.TabIndex = 3;
            this.label10.Text = "Adicionar Compra";
            // 
            // btn_fechar
            // 
            this.btn_fechar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_fechar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(99)))), ((int)(((byte)(161)))), ((int)(((byte)(116)))));
            this.btn_fechar.FlatAppearance.BorderColor = System.Drawing.Color.Goldenrod;
            this.btn_fechar.FlatAppearance.BorderSize = 0;
            this.btn_fechar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_fechar.ForeColor = System.Drawing.Color.Goldenrod;
            this.btn_fechar.Image = ((System.Drawing.Image)(resources.GetObject("btn_fechar.Image")));
            this.btn_fechar.Location = new System.Drawing.Point(668, 0);
            this.btn_fechar.Name = "btn_fechar";
            this.btn_fechar.Size = new System.Drawing.Size(45, 45);
            this.btn_fechar.TabIndex = 1;
            this.btn_fechar.UseVisualStyleBackColor = false;
            this.btn_fechar.Click += new System.EventHandler(this.btn_fechar_Click);
            // 
            // Adicionar_Compra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(713, 430);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Adicionar_Compra";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Adicionar_Compra";
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grp_parcelas.ResumeLayout(false);
            this.pnl_error.ResumeLayout(false);
            this.pnl_error.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel pnl_error;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbl_erro;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_salvar;
        private System.Windows.Forms.TextBox txt_aluno;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_fechar;
        private System.Windows.Forms.TextBox txt_curso;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rdbtn_nao;
        private System.Windows.Forms.RadioButton rdbtn_sim;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_valor;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmb_bonus;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MaskedTextBox txt_data;
        private System.Windows.Forms.ComboBox cmb_tipo;
        private System.Windows.Forms.GroupBox grp_parcelas;
        private System.Windows.Forms.Button btn_datas;
        private System.Windows.Forms.ComboBox cmb_quantidade;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbtn_naopago;
        private System.Windows.Forms.RadioButton rdbtn_pago;
        private System.Windows.Forms.TextBox txt_final;
    }
}