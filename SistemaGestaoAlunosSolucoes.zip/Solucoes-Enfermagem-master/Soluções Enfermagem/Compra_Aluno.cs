﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Soluções_Enfermagem
{
    public partial class Compra_Aluno : Form
    {
        Form currentChildForm;
        cmdAluno aluno = new cmdAluno();
        public Compra_Aluno(string c)
        {
            InitializeComponent();
            txt_curso.Text = c;
        }
        private void openChildForm(Form childForm)
        {
            if (currentChildForm != null)
            {
                currentChildForm.Close();
            }
            currentChildForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panel_conteudo.Controls.Add(childForm);
            childForm.BringToFront();
            childForm.Show();
        }

        private void btn_voltar_Click(object sender, EventArgs e)
        {
            openChildForm(new Compra_Curso());
        }

        private void btn_comprar_Click(object sender, EventArgs e)
        {
            if ((txt_aluno.Text == "{txt}") || (txt_aluno.Text == "Selecione um aluno"))
            {
                txt_aluno.Text = "Selecione um aluno";
                txt_aluno.Visible = true;
            }
            else
            {
                new Adicionar_Compra(txt_curso.Text, txt_aluno.Text).ShowDialog();
            }
        }

        private void Compra_Aluno_Load(object sender, EventArgs e)
        {
            MySqlDataReader temp = this.aluno.listarAlunos();
            DataTable dt = new DataTable();
            dt.Load(temp);
            table.DataSource = dt;
            this.aluno.fech();
        }

        private void btn_compra_atualizar_Click(object sender, EventArgs e)
        {
            MySqlDataReader temp = this.aluno.listarAlunos();
            DataTable dt = new DataTable();
            dt.Load(temp);
            table.DataSource = dt;
            this.aluno.fech();
        }

        private void btn_pesquisar_Click(object sender, EventArgs e)
        {
            List<string> filtro = new List<string>();
            if (txt_codigo.Text != "")
            {
                filtro.Add("num_aluno = '" + txt_codigo.Text + "'");
            }
            if (txt_nome.Text != "")
            {
                filtro.Add("nome like '%" + txt_nome.Text + "%'");
            }
            if (txt_cep.MaskFull == true)
            {
                filtro.Add("cep = '" + txt_cep.Text + "'");
            }
            if (txt_celular.MaskFull == true)
            {
                filtro.Add("celular = '" + txt_celular.Text + "'");
            }
            if (txt_cpf.MaskFull == true)
            {
                filtro.Add("cpf = '" + txt_cpf.Text + "'");
            }
            if (cmb_sexo.Text != "")
            {
                filtro.Add("sexo = '" + cmb_sexo.Text + "'");
            }
            if (filtro.Count != 0)
            {
                string pesquisa = String.Join("and ", filtro.ToArray());
                try
                {
                    MySqlDataReader temp = this.aluno.pequisarAlunos(pesquisa);
                    DataTable dt = new DataTable();
                    dt.Load(temp);
                    table.DataSource = dt;
                    this.aluno.fech();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void table_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataGridViewRow linha = table.Rows[e.RowIndex];
                txt_aluno.Text = linha.Cells[0].Value.ToString();
                txt_aluno.Visible = true;
            }
            catch (Exception ex)
            {

            }
        }
    }
}
