﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Soluções_Enfermagem
{
    public partial class Adicionar_Compra : Form
    {
        public string curso;
        public string aluno;
        private bool parcela;
        private DateTime primeira;
        private int intervalo;
        private string unidade;
        private bool bonus;
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        cmdCompra compra;

        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd,
                         int Msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        public Adicionar_Compra(string c, string a)
        {
            InitializeComponent();
            curso = c;
            aluno = a;
            parcela = false;
            txt_data.Text = DateTime.Now.ToString();
            compra = new cmdCompra(curso, aluno);
            txt_aluno.Text = compra.nome_aluno;
            txt_curso.Text = compra.nome_curso;
            txt_valor.Text = compra.valor.ToString();
            cmb_bonus.Text = compra.bonus;
            cmb_quantidade.Text = "1";
            if (cmb_bonus.Text == "Sim")
            {
                double value = compra.valor * 0.9;
                txt_final.Text = String.Format("{0:0.00}", value);
            }
            else
            {
                txt_final.Text = txt_valor.Text;
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e){}

        private void btn_fechar_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void rdbtn_sim_CheckedChanged(object sender, EventArgs e)
        {
            grp_parcelas.Visible = true;
            parcela = true;
            if (cmb_bonus.SelectedIndex == 0)
            {
                double value = (compra.valor * 0.9) / int.Parse(cmb_quantidade.Text);
                txt_final.Text = String.Format("{0:0.00}", value);
            }
            else
            {
                double value = compra.valor / int.Parse(cmb_quantidade.Text);
                txt_final.Text = String.Format("{0:0.00}", value);
            }
        }

        private void rdbtn_nao_CheckedChanged(object sender, EventArgs e)
        {
            grp_parcelas.Visible = false;
            parcela = false;
            if (cmb_bonus.Text == "Sim")
            {
                double value = compra.valor * 0.9;
                txt_final.Text = String.Format("{0:0.00}", value);
            }
            else
            {
                txt_final.Text = compra.valor.ToString();
            }
        }

        private void btn_datas_Click_1(object sender, EventArgs e)
        {
            if (this.intervalo==0)
            {
                Parcelas parcelas = new Parcelas();
                parcelas.ShowDialog();
                if (parcelas.DialogResult == DialogResult.OK)
                {
                    this.primeira = parcelas.primeiro;
                    txt_data.Text = primeira.ToString();
                    this.intervalo = parcelas.intervalo;
                    this.unidade = parcelas.unidade;
                }
            }
            else
            {
                Parcelas parcelas = new Parcelas(this.primeira, this.intervalo, this.unidade);
                parcelas.ShowDialog();
                if (parcelas.DialogResult == DialogResult.OK)
                {
                    this.primeira = parcelas.primeiro;
                    this.intervalo = parcelas.intervalo;
                    this.unidade = parcelas.unidade;
                }
            }
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmb_bonus.Text == "Sim")
            {
                double value = (compra.valor / int.Parse(cmb_quantidade.Text)) * 0.9;
                txt_final.Text = String.Format("{0:0.00}", value);
            }
            else
            {
                double value = (compra.valor / int.Parse(cmb_quantidade.Text));
                txt_final.Text = String.Format("{0:0.00}", value);
            }
        }

        private void btn_salvar_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmb_tipo.Text == "")
                {
                    lbl_erro.Text = "Tipo";
                    pnl_error.Visible = true;
                }
                else
                {
                    if (txt_data.MaskFull == false)
                    {
                        lbl_erro.Text = "Data";
                        pnl_error.Visible = true;
                    }
                    else
                    {

                        if (cmb_bonus.Text == "")
                        {
                            lbl_erro.Text = "Bonus";
                            pnl_error.Visible = true;
                        }
                        else
                        {
                            string total = txt_final.Text.Replace(',', '.');
                            if (cmb_bonus.Text == "Sim")
                            {
                                bonus = true;
                            }
                            else
                            {
                                bonus = false;
                            }
                            if (parcela == false)
                            {
                                if (rdbtn_pago.Checked)
                                {
                                    compra.efetuarCompra(total, cmb_tipo.Text, DateTime.Parse(txt_data.Text), "Pago", 1, bonus);
                                }
                                else
                                {
                                    compra.efetuarCompra(total, cmb_tipo.Text, DateTime.Parse(txt_data.Text), "Não Pago", 1, bonus);
                                }
                                if(compra.getInscrição(curso,aluno) == 1)
                                {
                                    this.compra.criarInscrição();
                                }
                                MessageBox.Show("Adicionado com sucesso");
                                Dispose();
                            }
                            else
                            {
                                if (this.intervalo == 0)
                                {
                                    lbl_erro.Text = "Datas";
                                    pnl_error.Visible = true;
                                }
                                else
                                {
                                    if (unidade == "")
                                    {
                                        lbl_erro.Text = "Bonus";
                                        pnl_error.Visible = true;
                                    }
                                    else
                                    {
                                        if (rdbtn_pago.Checked)
                                        {
                                            compra.efetuarCompra(total, cmb_tipo.Text, DateTime.Parse(txt_data.Text), "Pago", int.Parse(cmb_quantidade.Text), bonus);
                                        }
                                        else
                                        {
                                            compra.efetuarCompra(total, cmb_tipo.Text, DateTime.Parse(txt_data.Text), "Não Pago", int.Parse(cmb_quantidade.Text), bonus);
                                        }
                                        if (compra.getInscrição(curso, aluno) == 1)
                                        {
                                            this.compra.criarInscrição();
                                        }
                                        DateTime data = primeira;
                                        DateTime clone = data;
                                        int flag = 0;
                                        if (unidade == "Dia")
                                        {
                                            for (int i = 1; i < int.Parse(cmb_quantidade.Text); i++)
                                            {
                                                data = data.AddDays(this.intervalo);
                                                compra.efetuarCompra(total, cmb_tipo.Text, data, "Não Pago", int.Parse(cmb_quantidade.Text), bonus);
                                            }
                                        }
                                        if (unidade == "Mês")
                                        {
                                            for (int i = 1; i < int.Parse(cmb_quantidade.Text); i++)
                                            {
                                                data = data.AddMonths(this.intervalo);
                                                if (data.Day != primeira.Day)
                                                {
                                                    flag = 0;
                                                    clone = data;
                                                    do
                                                    {
                                                        clone = clone.AddDays(1);
                                                        if (clone.Month != data.Month || data.Day == primeira.Day)
                                                        {
                                                            flag = -1;
                                                        }
                                                        else
                                                        {
                                                            data = data.AddDays(1);
                                                        }
                                                    } while (flag == 0);
                                                    compra.efetuarCompra(total, cmb_tipo.Text, data, "Não Pago", int.Parse(cmb_quantidade.Text), bonus);
                                                }
                                                else
                                                {
                                                    compra.efetuarCompra(total, cmb_tipo.Text, data, "Não Pago", int.Parse(cmb_quantidade.Text), bonus);
                                                }

                                            }

                                            if (unidade == "Ano")
                                            {
                                                for (int i = 1; i < int.Parse(cmb_quantidade.Text); i++)
                                                {
                                                    data = data.AddYears(this.intervalo);
                                                    compra.efetuarCompra(total, cmb_tipo.Text, data, "Não Pago", int.Parse(cmb_quantidade.Text), bonus);
                                                }
                                            }
                                        }
                                        compra.mudarBonus();
                                        MessageBox.Show("Adicionados com sucesso");
                                        Dispose();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void rdbtn_pago_CheckedChanged(object sender, EventArgs e){}

        private void rdbtn_naopago_CheckedChanged(object sender, EventArgs e){}

        private void cmb_bonus_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(rdbtn_sim.Checked == true)
            {
                if (cmb_bonus.SelectedIndex == 0)
                {
                    double value = (compra.valor * 0.9)/int.Parse(cmb_quantidade.Text);
                    txt_final.Text = String.Format("{0:0.00}", value);
                }
                else
                {
                    double value = compra.valor / int.Parse(cmb_quantidade.Text);
                    txt_final.Text = String.Format("{0:0.00}", value);
                }
            }
            else
            {
                if (cmb_bonus.SelectedIndex == 0)
                {
                    double value = compra.valor * 0.9;
                    txt_final.Text = String.Format("{0:0.00}", value);
                }
                else
                {
                    double value = compra.valor;
                    txt_final.Text = String.Format("{0:0.00}", value);
                }
            }
        }
    }
}
